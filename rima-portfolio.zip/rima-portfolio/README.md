# Rima Zakiyatin · UI/UX Designer Portfolio

React + TypeScript + Tailwind CSS (v4) + Vite. No other runtime dependencies.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # type-check + production build into /dist
npm run preview    # serve the production build locally
```

Upload the `dist/` folder to any static host (Netlify, Vercel, GitHub Pages, cPanel). Paths are relative and routing uses `#hash` URLs, so no server configuration is needed.

## Deploy free on Vercel

1. Create an empty repository on GitHub (e.g. `rima-portfolio`).
2. Upload everything in this folder to it (drag & drop on GitHub works: "uploading an existing file"). Don't upload `node_modules` or `dist`.
3. Go to vercel.com → sign up with GitHub (Hobby plan, free) → **Add New → Project** → import the repository.
4. Vercel detects **Vite** automatically (settings are also in `vercel.json`). Click **Deploy**.
5. Your site is live at `https://<project-name>.vercel.app`. Every change you commit to GitHub redeploys automatically.

`npm run typecheck` runs the TypeScript check separately, so a type warning never blocks a deploy.

## Edit your content (no code knowledge needed)

| What | Where |
|---|---|
| Name, headline, bio, email, LinkedIn, tools, experience, skills | `src/data/profile.ts` |
| Projects, case-study text, screenshots, Figma links | `src/data/projects.ts` |
| Your CV | Replace `public/cv/Rima-Zakiyatin-CV.pdf` (keep the file name) |
| Your photo | Add e.g. `public/images/rima.jpg`, then set `photo: "images/rima.jpg"` in `profile.ts` |
| Colours & font | `src/index.css` (`@theme` block: `--color-brand-500` is #00809D) |

### Replace a placeholder with a real Figma screen

1. In Figma, select the frame → Export → PNG or WebP (1x or 2x).
2. Save it in `public/images/projects/<project-slug>/`, e.g. `public/images/projects/auth-system/login.webp`.
3. In `src/data/projects.ts`, add `src: "images/projects/auth-system/login.webp"` to that screen.
4. Paste your links into `figmaUrl` (design file) and `prototypeUrl` (Figma prototype "Present" link).

Any screen without `src` shows a neutral placeholder mockup labelled "add Figma export", so you can see at a glance what's still missing.

Screens are shown exactly as exported: no recolouring, no cropping (only card thumbnails show the top of the first screen).

## Still to fill in

- [ ] LinkedIn URL (`profile.linkedin`)
- [ ] Real CV PDF
- [ ] Photo (optional)
- [ ] Work experience entries (`profile.experience`)
- [ ] Screens, copy and Figma links for: Auth System, MyDewaruci, Register App, OPS App, Rules Development System, Certificate App
- [ ] Wireframes and prototype links for the Figma projects
- [ ] Check the draft case-study copy (written from the Figma screens) for every real project
- [ ] Year (and optionally team/duration) per project

## Structure

```
src/
  data/        profile.ts, projects.ts   ← your content
  pages/       Home, Projects, ProjectDetail (case study), About, Contact
  components/  Navbar, Footer, Button, ProjectCard, DeviceFrame (browser + phone mockups),
               PlaceholderScreen, Lightbox, SkillsGrid, ContactCTA, SectionHeading, Reveal, Icon, Avatar
  lib/         router.ts (tiny hash router), cn.ts
  hooks/       useReveal.ts (scroll animations, respects reduced-motion)
```
