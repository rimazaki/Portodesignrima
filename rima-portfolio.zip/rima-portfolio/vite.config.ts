import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// base "./" keeps every asset path relative, so the build works on any static host
// (Netlify, Vercel, GitHub Pages, cPanel) without extra rewrite rules.
export default defineConfig({
  base: "./",
  plugins: [react(), tailwindcss()],
});
