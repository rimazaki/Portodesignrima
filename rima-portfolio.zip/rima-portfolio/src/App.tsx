import { useEffect } from "react";
import { Footer } from "./components/Footer";
import { Navbar } from "./components/Navbar";
import { useRoute } from "./lib/router";
import { About } from "./pages/About";
import { Contact } from "./pages/Contact";
import { Home } from "./pages/Home";
import { ProjectDetail } from "./pages/ProjectDetail";
import { Projects } from "./pages/Projects";

const TITLES = {
  home: "Rima Zakiyatin · UI/UX Designer",
  work: "Projects · Rima Zakiyatin",
  about: "About · Rima Zakiyatin",
  contact: "Contact · Rima Zakiyatin",
} as const;

export default function App() {
  const route = useRoute();
  const key = route.name === "case" ? `case-${route.slug}` : route.name;

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    if (route.name !== "case") document.title = TITLES[route.name];
  }, [key]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[70] focus:rounded-full focus:bg-white focus:px-4 focus:py-2 focus:font-semibold focus:shadow" onClick={(e) => { e.preventDefault(); document.getElementById("main")?.focus(); }}>
        Skip to content
      </a>
      <Navbar />
      <main id="main" tabIndex={-1} key={key} className="outline-none">
        {route.name === "home" && <Home />}
        {route.name === "work" && <Projects />}
        {route.name === "case" && <ProjectDetail slug={route.slug} />}
        {route.name === "about" && <About />}
        {route.name === "contact" && <Contact />}
      </main>
      <Footer />
    </>
  );
}
