import { useEffect, useState } from "react";
import { profile } from "../data/profile";
import { cn } from "../lib/cn";
import { isActive, paths, useRoute } from "../lib/router";
import { ButtonLink } from "./Button";
import { Icon } from "./Icon";

const links = [
  { label: "Home", href: paths.home },
  { label: "Projects", href: paths.work },
  { label: "About", href: paths.about },
  { label: "Contact", href: paths.contact },
];

export function Navbar() {
  const route = useRoute();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [route]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled || open ? "bg-white/85 shadow-[0_1px_0_0_var(--color-ink-100)] backdrop-blur-xl" : "bg-transparent",
      )}
    >
      <nav className="mx-auto flex h-18 max-w-7xl items-center justify-between px-5 sm:px-8" aria-label="Main">
        <a href={paths.home} className="group flex items-center gap-3" aria-label={`${profile.name}, home`}>
          <span className="grid size-10 place-items-center rounded-xl bg-brand-500 text-sm font-extrabold text-white transition-transform duration-300 group-hover:rotate-[-6deg]">
            {profile.initials}
          </span>
          <span className="hidden leading-tight sm:block">
            <span className="block text-[15px] font-bold text-ink-950">{profile.name}</span>
            <span className="block text-xs font-medium text-ink-500">{profile.role}</span>
          </span>
        </a>

        <ul className="hidden items-center gap-1 rounded-full bg-white/70 p-1 ring-1 ring-ink-100 backdrop-blur md:flex">
          {links.map((l) => {
            const active = isActive(route, l.href);
            return (
              <li key={l.href}>
                <a
                  href={l.href}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "relative block rounded-full px-4 py-2 text-sm font-semibold transition-colors duration-300",
                    active ? "bg-brand-50 text-brand-700" : "text-ink-600 hover:text-ink-950",
                  )}
                >
                  {l.label}
                </a>
              </li>
            );
          })}
        </ul>

        <div className="flex items-center gap-2">
          <ButtonLink href={profile.cvUrl} download variant="primary" icon="download" className="hidden sm:inline-flex">
            Download CV
          </ButtonLink>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full text-ink-900 ring-1 ring-ink-200 md:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "Close menu" : "Open menu"}
          >
            <Icon name={open ? "close" : "menu"} />
          </button>
        </div>
      </nav>

      <div
        id="mobile-menu"
        className={cn(
          "overflow-hidden border-t border-ink-100 bg-white transition-[max-height,opacity] duration-500 ease-[var(--ease-out-soft)] md:hidden",
          open ? "max-h-[420px] opacity-100" : "max-h-0 opacity-0",
        )}
      >
        <ul className="flex flex-col gap-1 px-5 py-4">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                tabIndex={open ? 0 : -1}
                className={cn(
                  "flex items-center justify-between rounded-2xl px-4 py-3.5 text-lg font-bold",
                  isActive(route, l.href) ? "bg-brand-50 text-brand-700" : "text-ink-900",
                )}
              >
                {l.label}
                <Icon name="arrow-right" className="size-5 text-ink-300" />
              </a>
            </li>
          ))}
          <li className="pt-3">
            <ButtonLink href={profile.cvUrl} download icon="download" className="w-full" tabIndex={open ? 0 : -1}>
              Download CV
            </ButtonLink>
          </li>
        </ul>
      </div>
    </header>
  );
}
