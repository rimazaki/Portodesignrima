import { skills } from "../data/profile";
import { Icon } from "./Icon";
import { Reveal } from "./Reveal";

export function SkillsGrid() {
  return (
    <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {skills.map((s, i) => (
        <Reveal as="li" key={s.name} delay={(i % 4) * 70}>
          <div className="group h-full rounded-3xl bg-white p-6 ring-1 ring-ink-100 transition-all duration-500 ease-[var(--ease-out-soft)] hover:-translate-y-1 hover:shadow-[0_30px_60px_-35px_rgba(0,90,111,0.4)] hover:ring-brand-200">
            <span className="mb-6 grid size-12 place-items-center rounded-2xl bg-brand-50 text-brand-600 transition-colors duration-300 group-hover:bg-brand-500 group-hover:text-white">
              <Icon name={s.icon} className="size-[22px]" />
            </span>
            <h3 className="text-lg font-bold text-ink-950">{s.name}</h3>
            <p className="mt-2 text-[15px] leading-relaxed text-ink-500">{s.description}</p>
          </div>
        </Reveal>
      ))}
    </ul>
  );
}
