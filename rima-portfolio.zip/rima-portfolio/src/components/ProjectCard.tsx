import { coverPhones, type Project } from "../data/projects";
import { paths } from "../lib/router";
import { cn } from "../lib/cn";
import { BrowserFrame, PhoneFrame, PhoneTrio } from "./DeviceFrame";
import { Icon } from "./Icon";

type Props = { project: Project; index?: number; size?: "lg" | "md" };

export function ProjectCard({ project, index, size = "md" }: Props) {
  const number = index !== undefined ? String(index + 1).padStart(2, "0") : null;
  return (
    <a
      href={paths.caseStudy(project.slug)}
      className="group flex h-full flex-col rounded-[28px] bg-white p-3 ring-1 ring-ink-100 transition-all duration-500 ease-[var(--ease-out-soft)] hover:-translate-y-1.5 hover:shadow-[0_40px_80px_-40px_rgba(0,90,111,0.35)] hover:ring-brand-200"
      aria-label={`Open case study: ${project.title}`}
    >
      <div
        className={cn(
          "bg-dots relative overflow-hidden rounded-[20px] bg-ink-50 px-[7%] pt-[7%]",
          size === "lg" ? "aspect-[16/11]" : "aspect-[4/3]",
        )}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-brand-50/0 via-brand-50/0 to-brand-100/50 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
        {project.cover.device === "mobile" ? (
          <PhoneTrio screens={coverPhones(project)} className="relative mx-auto w-[88%]" />
        ) : (
          <BrowserFrame
            screen={project.cover}
            crop
            panOnHover
            className="relative transition-transform duration-700 ease-[var(--ease-out-soft)] group-hover:scale-[1.02]"
          />
        )}
        {project.coverMobile && (
          <PhoneFrame
            screen={project.coverMobile}
            crop
            tilt={{ rx: 6, ry: -22, rz: 2 }}
            className="absolute bottom-[-14%] right-[5%] w-[23%] transition-transform duration-700 ease-[var(--ease-out-soft)] group-hover:-translate-y-3"
          />
        )}
      </div>

      <div className="flex flex-1 flex-col gap-3 px-3 pb-3 pt-5 sm:px-4">
        <div className="flex items-center justify-between gap-3 text-xs font-semibold">
          <span className="text-brand-600">{project.category}</span>
          {number && <span className="tabular-nums text-ink-300">{number}</span>}
        </div>
        <h3 className={cn("font-extrabold tracking-tight text-ink-950", size === "lg" ? "text-2xl sm:text-[28px]" : "text-xl sm:text-2xl")}>
          {project.title}
        </h3>
        <p className="line-clamp-2 text-[15px] leading-relaxed text-ink-500">{project.summary}</p>
        <div className="mt-auto flex items-center justify-between gap-3 pt-2">
          <div className="flex flex-wrap gap-1.5">
            {project.tags.slice(0, 3).map((t) => (
              <span key={t} className="rounded-full bg-ink-50 px-2.5 py-1 text-[11px] font-semibold text-ink-600 ring-1 ring-ink-100">
                {t}
              </span>
            ))}
          </div>
          <span className="grid size-10 shrink-0 place-items-center rounded-full bg-ink-50 text-ink-700 ring-1 ring-ink-100 transition-all duration-300 group-hover:bg-brand-500 group-hover:text-white group-hover:ring-brand-500">
            <Icon name="arrow-up-right" className="size-[18px] transition-transform duration-300 group-hover:rotate-45" />
          </span>
        </div>
      </div>
    </a>
  );
}
