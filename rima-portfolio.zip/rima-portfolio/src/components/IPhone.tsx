import { useRef, useState, type CSSProperties, type PointerEvent } from "react";
import type { Screen } from "../data/projects";
import { cn } from "../lib/cn";
import { PlaceholderScreen } from "./PlaceholderScreen";

export type Tilt = { rx?: number; ry?: number; rz?: number };

type Props = {
  screen: Screen;
  className?: string;
  /** Resting rotation in degrees. */
  tilt?: Tilt;
  /** Follow the pointer with a gentle 3D tilt. */
  interactive?: boolean;
  /** Show only the first viewport (thumbnails). Otherwise long screens scroll inside the phone. */
  crop?: boolean;
  eager?: boolean;
  shadow?: boolean;
};

const EDGE_LAYERS = 12;
const reducedMotion = () => typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

/**
 * Realistic 3D iPhone (titanium frame, side buttons, Dynamic Island, real thickness).
 * Your exported screen is placed inside unchanged; only a faint glass reflection sits on top.
 */
export function IPhone({ screen, className, tilt, interactive = false, crop = false, eager, shadow = true }: Props) {
  const phone = useRef<HTMLDivElement>(null);
  const [scrolled, setScrolled] = useState(false);
  const rest = { rx: tilt?.rx ?? 0, ry: tilt?.ry ?? 0, rz: tilt?.rz ?? 0 };

  const setVars = (rx: number, ry: number, rz: number) => {
    const el = phone.current;
    if (!el) return;
    el.style.setProperty("--rx", `${rx}deg`);
    el.style.setProperty("--ry", `${ry}deg`);
    el.style.setProperty("--rz", `${rz}deg`);
  };

  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    if (!interactive || e.pointerType !== "mouse" || reducedMotion()) return;
    const r = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    phone.current?.classList.add("is-tracking");
    setVars(rest.rx - y * 14, rest.ry + x * 22, rest.rz);
  };
  const onLeave = () => {
    phone.current?.classList.remove("is-tracking");
    setVars(rest.rx, rest.ry, rest.rz);
  };

  const style = { "--rx": `${rest.rx}deg`, "--ry": `${rest.ry}deg`, "--rz": `${rest.rz}deg` } as CSSProperties;
  const long = !crop && !!screen.src;

  return (
    <div className={cn("iphone-stage", className)} onPointerMove={onMove} onPointerLeave={onLeave}>
      {shadow && <div className="iphone-shadow" aria-hidden="true" />}
      <div ref={phone} className="iphone" style={style}>
        {Array.from({ length: EDGE_LAYERS }, (_, i) => (
          <div key={i} className="iphone-edge" style={{ ["--i" as string]: i + 1 }} aria-hidden="true" />
        ))}
        <div className="iphone-body">
          <span className="iphone-btn l" style={{ top: "17%", height: "4.5%" }} aria-hidden="true" />
          <span className="iphone-btn l" style={{ top: "25.5%", height: "8.5%" }} aria-hidden="true" />
          <span className="iphone-btn l" style={{ top: "36%", height: "8.5%" }} aria-hidden="true" />
          <span className="iphone-btn r" style={{ top: "28%", height: "13%" }} aria-hidden="true" />
          <div className="iphone-bezel">
            <div className="iphone-screen">
              {screen.src ? (
                crop ? (
                  <img
                    src={screen.src}
                    alt={screen.title}
                    loading={eager ? "eager" : "lazy"}
                    decoding="async"
                    className="absolute inset-0 h-full w-full object-cover object-top"
                  />
                ) : (
                  <div className="iphone-scroll" onScroll={(e) => !scrolled && e.currentTarget.scrollTop > 8 && setScrolled(true)}>
                    <img src={screen.src} alt={screen.title} loading={eager ? "eager" : "lazy"} decoding="async" className="block w-full" />
                  </div>
                )
              ) : (
                <PlaceholderScreen device="mobile" label={screen.title} className="absolute inset-0 pt-[12%]" />
              )}
              <div className="iphone-island" aria-hidden="true" />
              <div className="iphone-glare" aria-hidden="true" />
              {long && screen.tall && (
                <span className="iphone-hint" style={{ opacity: scrolled ? 0 : 1 }}>Scroll inside the phone</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
