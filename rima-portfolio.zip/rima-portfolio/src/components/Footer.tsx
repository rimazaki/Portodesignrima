import { profile } from "../data/profile";
import { paths } from "../lib/router";
import { Icon } from "./Icon";

export function Footer() {
  return (
    <footer className="border-t border-ink-100 bg-white">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 py-12 sm:px-8 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-3">
          <span className="grid size-10 place-items-center rounded-xl bg-brand-500 text-sm font-extrabold text-white">{profile.initials}</span>
          <div className="leading-tight">
            <p className="font-bold text-ink-950">{profile.name}</p>
            <p className="text-sm text-ink-500">{profile.role} · {profile.location}</p>
          </div>
        </div>
        <nav className="flex flex-wrap gap-x-6 gap-y-2 text-sm font-semibold text-ink-600" aria-label="Footer">
          <a className="hover:text-brand-600" href={paths.work}>Projects</a>
          <a className="hover:text-brand-600" href={paths.about}>About</a>
          <a className="hover:text-brand-600" href={paths.contact}>Contact</a>
          <a className="hover:text-brand-600" href={profile.cvUrl} download>Download CV</a>
        </nav>
        <div className="flex items-center gap-2">
          <a href={`mailto:${profile.email}`} aria-label="Email" className="grid size-10 place-items-center rounded-full text-ink-600 ring-1 ring-ink-200 transition hover:bg-brand-500 hover:text-white hover:ring-brand-500">
            <Icon name="mail" className="size-[18px]" />
          </a>
          <a href={profile.linkedin} target="_blank" rel="noreferrer" aria-label="LinkedIn" className="grid size-10 place-items-center rounded-full text-ink-600 ring-1 ring-ink-200 transition hover:bg-brand-500 hover:text-white hover:ring-brand-500">
            <Icon name="linkedin" className="size-[18px]" />
          </a>
          <a href={profile.figma} target="_blank" rel="noreferrer" aria-label="Figma" className="grid size-10 place-items-center rounded-full text-ink-600 ring-1 ring-ink-200 transition hover:bg-brand-500 hover:text-white hover:ring-brand-500">
            <Icon name="figma" className="size-[18px]" />
          </a>
        </div>
      </div>
      <p className="border-t border-ink-100 py-5 text-center text-xs text-ink-400">© {new Date().getFullYear()} {profile.name}. Designed in Figma, built with React.</p>
    </footer>
  );
}
