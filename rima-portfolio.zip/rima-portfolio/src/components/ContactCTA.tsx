import { profile } from "../data/profile";
import { paths } from "../lib/router";
import { ButtonLink } from "./Button";
import { Container } from "./Container";
import { Reveal } from "./Reveal";

export function ContactCTA() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <Reveal className="relative overflow-hidden rounded-[36px] bg-brand-800 px-6 py-14 text-white sm:px-14 sm:py-20">
          <div className="pointer-events-none absolute -right-24 -top-24 size-96 rounded-full bg-brand-500/40 blur-3xl" aria-hidden="true" />
          <div className="pointer-events-none absolute -bottom-32 left-1/3 size-80 rounded-full bg-brand-400/20 blur-3xl" aria-hidden="true" />
          <div className="relative grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:items-end">
            <div>
              <p className="mb-5 text-xs font-bold uppercase tracking-[0.18em] text-brand-200">Available for new roles</p>
              <h2 className="text-3xl font-extrabold leading-[1.1] tracking-tight sm:text-5xl">
                Let's build products your users will thank you for.
              </h2>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-brand-100 sm:text-lg">
                Open to UI/UX Designer roles with local and international teams, full-time or remote.
              </p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row lg:flex-col lg:items-stretch">
              <ButtonLink href={paths.contact} size="lg" icon="arrow-right" variant="light">
                Contact me
              </ButtonLink>
              <ButtonLink href={profile.cvUrl} download size="lg" variant="outline-light" icon="download">
                Download CV
              </ButtonLink>
            </div>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
