import { profile } from "../data/profile";
import { cn } from "../lib/cn";

/** Shows profile.photo if set, otherwise a branded initials tile. */
export function Avatar({ className }: { className?: string }) {
  if (profile.photo) {
    return <img src={profile.photo} alt={profile.name} className={cn("object-cover", className)} />;
  }
  return (
    <div className={cn("relative grid place-items-center overflow-hidden bg-gradient-to-br from-brand-500 via-brand-600 to-brand-800", className)} role="img" aria-label={profile.name}>
      <div className="bg-dots absolute inset-0 opacity-20" aria-hidden="true" />
      <div className="absolute -right-10 -top-10 size-48 rounded-full bg-white/10" aria-hidden="true" />
      <span className="relative text-7xl font-extrabold tracking-tight text-white/95">{profile.initials}</span>
      <span className="absolute bottom-5 left-5 rounded-full bg-white/15 px-3 py-1 text-[11px] font-semibold text-white backdrop-blur">
        Add your photo in profile.ts
      </span>
    </div>
  );
}
