import { useCallback, useEffect, useRef } from "react";
import type { Screen } from "../data/projects";
import { cn } from "../lib/cn";
import { Icon } from "./Icon";
import { PlaceholderScreen } from "./PlaceholderScreen";

type Props = {
  screens: Screen[];
  index: number | null;
  onChange: (i: number | null) => void;
  projectTitle: string;
};

/** Full-screen viewer for final screens: arrow keys / buttons to move, Esc to close. */
export function Lightbox({ screens, index, onChange, projectTitle }: Props) {
  const closeRef = useRef<HTMLButtonElement>(null);
  const open = index !== null;
  const screen = open ? screens[index] : null;

  const go = useCallback(
    (d: number) => index !== null && onChange((index + d + screens.length) % screens.length),
    [index, onChange, screens.length],
  );

  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onChange(null);
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      prev?.focus?.();
    };
  }, [open, go, onChange]);

  if (!open || !screen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-ink-950/95 backdrop-blur-sm animate-[fade-up_.35s_var(--ease-out-soft)_both]" role="dialog" aria-modal="true" aria-label={`${projectTitle} screens`}>
      <div className="flex items-center justify-between gap-4 border-b border-white/10 px-4 py-3 text-white sm:px-6">
        <p className="min-w-0 truncate text-sm">
          <span className="font-bold">{projectTitle}</span>
          <span className="text-white/60"> · {screen.title} · {index! + 1}/{screens.length}</span>
        </p>
        <div className="flex gap-2">
          <button type="button" onClick={() => go(-1)} aria-label="Previous screen" className="grid size-10 place-items-center rounded-full bg-white/10 hover:bg-white/20">
            <Icon name="chevron-left" />
          </button>
          <button type="button" onClick={() => go(1)} aria-label="Next screen" className="grid size-10 place-items-center rounded-full bg-white/10 hover:bg-white/20">
            <Icon name="chevron-right" />
          </button>
          <button ref={closeRef} type="button" onClick={() => onChange(null)} aria-label="Close viewer" className="grid size-10 place-items-center rounded-full bg-white text-ink-950 hover:bg-brand-100">
            <Icon name="close" />
          </button>
        </div>
      </div>
      <div className="flex flex-1 justify-center overflow-auto p-4 sm:p-8" onClick={(e) => e.target === e.currentTarget && onChange(null)}>
        <div className={cn("my-auto h-fit", screen.device === "mobile" ? "w-full max-w-sm" : "w-full max-w-6xl")}>
          {screen.src ? (
            <img src={screen.src} alt={screen.title} className="w-full rounded-xl bg-white shadow-2xl" />
          ) : (
            <div className={cn("overflow-hidden rounded-xl", screen.device === "mobile" ? "aspect-[9/19.5]" : "aspect-[16/10]")}>
              <PlaceholderScreen device={screen.device} label={screen.title} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
