import type { Device } from "../data/projects";
import { cn } from "../lib/cn";

/**
 * Neutral skeleton UI shown wherever a real Figma export hasn't been added yet.
 * Add `src` to the screen in src/data/projects.ts and this disappears automatically.
 */
export function PlaceholderScreen({ device, label, className }: { device: Device; label?: string; className?: string }) {
  if (device === "mobile") {
    return (
      <div className={cn("relative flex h-full w-full flex-col gap-3 bg-ink-50 p-4", className)} aria-label={label ? `${label} (placeholder)` : "Placeholder"}>
        <div className="h-24 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 opacity-90" />
        <div className="grid grid-cols-4 gap-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="aspect-square rounded-xl bg-white ring-1 ring-ink-100" />
          ))}
        </div>
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 rounded-xl bg-white p-3 ring-1 ring-ink-100">
            <div className="size-8 rounded-lg bg-brand-100" />
            <div className="flex-1 space-y-1.5">
              <div className="h-2 w-3/4 rounded bg-ink-200" />
              <div className="h-2 w-1/2 rounded bg-ink-100" />
            </div>
          </div>
        ))}
        <PlaceholderBadge label={label} />
      </div>
    );
  }
  return (
    <div className={cn("relative flex h-full w-full bg-ink-50", className)} aria-label={label ? `${label} (placeholder)` : "Placeholder"}>
      <div className="hidden w-[18%] flex-col gap-2 bg-brand-800 p-[3%] sm:flex">
        <div className="mb-3 h-3 w-2/3 rounded bg-white/70" />
        {Array.from({ length: 7 }).map((_, i) => (
          <div key={i} className={cn("h-2 rounded bg-white/20", i === 1 && "bg-white/60")} style={{ width: `${55 + ((i * 13) % 35)}%` }} />
        ))}
      </div>
      <div className="flex flex-1 flex-col gap-[3%] p-[3%]">
        <div className="h-3 w-1/3 rounded bg-ink-300" />
        <div className="grid grid-cols-3 gap-[3%]">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="rounded-lg bg-white p-[8%] ring-1 ring-ink-100">
              <div className="mb-2 h-2 w-1/2 rounded bg-ink-200" />
              <div className="h-4 w-2/3 rounded bg-brand-200" />
            </div>
          ))}
        </div>
        <div className="flex-1 space-y-[2.5%] rounded-lg bg-white p-[3%] ring-1 ring-ink-100">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="flex items-center gap-[4%]">
              <div className="h-2 flex-1 rounded bg-ink-100" />
              <div className="h-2 flex-1 rounded bg-ink-100" />
              <div className="h-2 w-[14%] rounded-full bg-brand-100" />
            </div>
          ))}
        </div>
      </div>
      <PlaceholderBadge label={label} />
    </div>
  );
}

function PlaceholderBadge({ label }: { label?: string }) {
  return (
    <div className="pointer-events-none absolute inset-0 grid place-items-center p-4">
      <span className="rounded-full bg-white/90 px-3 py-1.5 text-center text-[11px] font-semibold text-ink-500 shadow-sm ring-1 ring-ink-200 backdrop-blur">
        {label ? `${label} · ` : ""}add Figma export
      </span>
    </div>
  );
}
