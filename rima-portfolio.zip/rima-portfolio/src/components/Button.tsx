import type { AnchorHTMLAttributes, ReactNode } from "react";
import { cn } from "../lib/cn";
import { Icon, type IconName } from "./Icon";

type Variant = "primary" | "secondary" | "ghost" | "light" | "outline-light";
type Size = "md" | "lg";

const base =
  "group inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-all duration-300 ease-[var(--ease-out-soft)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-500 active:scale-[0.98]";

const variants: Record<Variant, string> = {
  primary:
    "bg-brand-500 text-white shadow-[0_10px_30px_-12px_rgba(0,128,157,0.7)] hover:bg-brand-600 hover:shadow-[0_14px_34px_-12px_rgba(0,128,157,0.8)]",
  secondary: "bg-white text-ink-900 ring-1 ring-ink-200 hover:ring-brand-300 hover:text-brand-700 hover:bg-brand-50/40",
  ghost: "text-ink-700 hover:text-brand-600",
  /** White button for dark backgrounds. */
  light: "bg-white text-brand-800 hover:bg-brand-50",
  /** Outlined button for dark backgrounds. */
  "outline-light": "bg-transparent text-white ring-1 ring-white/30 hover:bg-white/10 hover:ring-white/60",
};

const sizes: Record<Size, string> = {
  md: "h-11 px-5 text-sm",
  lg: "h-13 px-7 text-[15px]",
};

type Props = AnchorHTMLAttributes<HTMLAnchorElement> & {
  variant?: Variant;
  size?: Size;
  icon?: IconName;
  iconPosition?: "left" | "right";
  children: ReactNode;
};

/** Link styled as a button. Every CTA on the site navigates or downloads, so it is always an <a>. */
export function ButtonLink({ variant = "primary", size = "md", icon, iconPosition = "right", className, children, ...rest }: Props) {
  const iconEl = icon ? (
    <Icon
      name={icon}
      className={cn(
        "size-[18px] transition-transform duration-300",
        icon.startsWith("arrow-right") && "group-hover:translate-x-0.5",
        icon === "arrow-up-right" && "group-hover:-translate-y-0.5 group-hover:translate-x-0.5",
        icon === "download" && "group-hover:translate-y-0.5",
      )}
    />
  ) : null;
  return (
    <a className={cn(base, variants[variant], sizes[size], className)} {...rest}>
      {iconPosition === "left" && iconEl}
      {children}
      {iconPosition === "right" && iconEl}
    </a>
  );
}
