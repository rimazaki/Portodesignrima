import type { ReactNode } from "react";
import type { Screen } from "../data/projects";
import { cn } from "../lib/cn";
import { IPhone, type Tilt } from "./IPhone";
import { PlaceholderScreen } from "./PlaceholderScreen";

type FrameProps = {
  screen: Screen;
  className?: string;
  /** Crop the screen to a fixed aspect ratio (card thumbnails). Full screens are never cropped. */
  crop?: boolean;
  /** On hover, slowly pan a cropped screen from top to bottom. */
  panOnHover?: boolean;
  url?: string;
  eager?: boolean;
};

/** Caps very long pages (landing pages, docs) and fades the bottom; the viewer shows the full length. */
function TallCap({ tall, children }: { tall?: boolean; children: ReactNode }) {
  if (!tall) return <>{children}</>;
  return (
    <div className="relative max-h-[620px] overflow-hidden">
      {children}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex h-36 items-end justify-center bg-gradient-to-b from-white/0 via-white/70 to-white pb-4">
        <span className="rounded-full bg-ink-950/85 px-3 py-1.5 text-[11px] font-semibold text-white">Full page · open to view</span>
      </div>
    </div>
  );
}

/** Desktop screenshot inside a minimal browser window. The design itself is shown untouched. */
export function BrowserFrame({ screen, className, crop, panOnHover, url, eager }: FrameProps) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-xl bg-white shadow-[0_30px_60px_-30px_rgba(11,20,24,0.35)] ring-1 ring-ink-900/10",
        className,
      )}
    >
      <div className="flex h-8 items-center gap-3 border-b border-ink-100 bg-ink-50/80 px-3">
        <div className="flex gap-1.5" aria-hidden="true">
          <span className="size-2.5 rounded-full bg-[#ff5f57]" />
          <span className="size-2.5 rounded-full bg-[#febc2e]" />
          <span className="size-2.5 rounded-full bg-[#28c840]" />
        </div>
        <div className="mx-auto hidden h-5 w-1/2 max-w-xs items-center justify-center truncate rounded-md bg-white px-2 text-[10px] font-medium text-ink-400 ring-1 ring-ink-100 sm:flex">
          {url ?? screen.title}
        </div>
      </div>
      <div className={cn("relative overflow-hidden bg-white", crop && "aspect-[16/10]")}>
        {screen.src ? (
          <TallCap tall={!crop && screen.tall}>
            <img
              src={screen.src}
              alt={screen.title}
              loading={eager ? "eager" : "lazy"}
              decoding="async"
              className={cn(
                "block w-full",
                crop && "absolute inset-0 h-full object-cover object-top",
                crop && panOnHover && !screen.tall && "transition-[object-position] duration-[2600ms] ease-in-out group-hover:object-bottom",
              )}
            />
          </TallCap>
        ) : (
          <div className={cn(crop ? "absolute inset-0" : "aspect-[16/10]")}>
            <PlaceholderScreen device="desktop" label={screen.title} />
          </div>
        )}
      </div>
    </div>
  );
}

/** Mobile screenshot inside a realistic 3D iPhone. */
export function PhoneFrame({ screen, className, eager, crop, tilt, interactive }: FrameProps & { tilt?: Tilt; interactive?: boolean }) {
  return <IPhone screen={screen} className={className} eager={eager} crop={crop} tilt={tilt} interactive={interactive} />;
}

export function DeviceFrame(props: FrameProps & { tilt?: Tilt; interactive?: boolean }) {
  return props.screen.device === "mobile" ? <PhoneFrame {...props} /> : <BrowserFrame {...props} />;
}

/** Three 3D iPhones fanned out, the middle one in front. Cover for mobile-first projects. */
export function PhoneTrio({ screens, className, eager, interactive }: { screens: Screen[]; className?: string; eager?: boolean; interactive?: boolean }) {
  const [a, b, c] = screens;
  return (
    <div className={cn("relative flex items-end justify-center", className)}>
      {a && (
        <div className="relative z-0 -mr-[4%] w-[31%] translate-y-[6%] transition-transform duration-700 ease-[var(--ease-out-soft)] group-hover:translate-y-[3%]">
          <IPhone screen={a} crop eager={eager} tilt={{ rx: 6, ry: 28, rz: -2 }} interactive={interactive} />
        </div>
      )}
      {b && (
        <div className="relative z-10 w-[35%] transition-transform duration-700 ease-[var(--ease-out-soft)] group-hover:-translate-y-[3%]">
          <IPhone screen={b} crop eager={eager} tilt={{ rx: 8, ry: 0 }} interactive={interactive} />
        </div>
      )}
      {c && (
        <div className="relative z-0 -ml-[4%] w-[31%] translate-y-[6%] transition-transform duration-700 ease-[var(--ease-out-soft)] group-hover:translate-y-[3%]">
          <IPhone screen={c} crop eager={eager} tilt={{ rx: 6, ry: -28, rz: 2 }} interactive={interactive} />
        </div>
      )}
    </div>
  );
}
