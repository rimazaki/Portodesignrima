import { useEffect, useState, type ReactNode } from "react";
import { coverPhones, getProject, projects, type Project, type Screen } from "../data/projects";
import { cn } from "../lib/cn";
import { paths } from "../lib/router";
import { ButtonLink } from "../components/Button";
import { Container } from "../components/Container";
import { ContactCTA } from "../components/ContactCTA";
import { BrowserFrame, DeviceFrame, PhoneFrame, PhoneTrio } from "../components/DeviceFrame";
import { Icon } from "../components/Icon";
import { Lightbox } from "../components/Lightbox";
import { Reveal } from "../components/Reveal";

const SECTIONS = [
  { id: "overview", label: "Project Overview" },
  { id: "problem", label: "Problem & Solution" },
  { id: "role", label: "My Role" },
  { id: "flow", label: "User Flow" },
  { id: "wireframe", label: "Wireframe" },
  { id: "ui", label: "UI Design" },
  { id: "screens", label: "Final Screens" },
  { id: "prototype", label: "Prototype" },
] as const;

export function ProjectDetail({ slug }: { slug: string }) {
  const project = getProject(slug);
  if (!project) return <NotFound />;
  return <CaseStudy key={project.slug} project={project} />;
}

function CaseStudy({ project: p }: { project: Project }) {
  const [lightbox, setLightbox] = useState<number | null>(null);
  const active = useActiveSection();
  const idx = projects.indexOf(p);
  const next = projects[(idx + 1) % projects.length];
  const cs = p.caseStudy;

  useEffect(() => {
    document.title = `${p.title} · Case study · Rima Zakiyatin`;
  }, [p.title]);

  const sections = SECTIONS.filter((s) => s.id !== "wireframe" || cs.wireframes.length > 0);
  const num = (id: string) => String(sections.findIndex((s) => s.id === id) + 1).padStart(2, "0");
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden pb-14 pt-28 sm:pt-36">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[520px] bg-[radial-gradient(55%_65%_at_80%_10%,var(--color-brand-50),transparent_70%)]" aria-hidden="true" />
        <Container className="relative">
          <a href={paths.work} className="group inline-flex items-center gap-2 text-sm font-semibold text-ink-500 hover:text-brand-600">
            <Icon name="arrow-left" className="size-4 transition-transform group-hover:-translate-x-0.5" />
            All projects
          </a>
          <div className="mt-8 grid gap-10 lg:grid-cols-[1.3fr_1fr] lg:items-end">
            <div>
              <p className="animate-fade-up text-sm font-bold text-brand-600">{p.category}{p.industry ? ` · ${p.industry}` : ""}</p>
              <h1 className="animate-fade-up mt-3 text-4xl font-extrabold leading-[1.02] tracking-[-0.03em] text-ink-950 [animation-delay:60ms] sm:text-6xl lg:text-7xl">{p.title}</h1>
              <p className="animate-fade-up mt-6 max-w-2xl text-lg leading-relaxed text-ink-500 [animation-delay:120ms]">{p.summary}</p>
            </div>
            <dl className="animate-fade-up grid grid-cols-2 gap-x-6 gap-y-5 rounded-3xl bg-white p-6 ring-1 ring-ink-100 [animation-delay:180ms]">
              <Meta label="Role" value={cs.role.title} />
              <Meta label="Platform" value={p.platform} />
              <Meta label="Industry" value={p.industry ?? "Add industry"} muted={!p.industry} />
              <Meta label="Year" value={p.year ?? "Add year"} muted={!p.year} />
              <div className="col-span-2 flex flex-wrap gap-2 border-t border-ink-100 pt-5">
                {p.figmaUrl ? (
                  <ButtonLink href={p.figmaUrl} target="_blank" rel="noreferrer" icon="figma" iconPosition="left" variant="secondary">View in Figma</ButtonLink>
                ) : (
                  <span className="text-sm text-ink-400">Add a Figma link in projects.ts</span>
                )}
              </div>
            </dl>
          </div>
        </Container>
      </section>

      {/* Cover */}
      <section className="pb-6">
        <Container>
          <Reveal className="bg-dots relative overflow-hidden rounded-[36px] bg-ink-50 px-[6%] pt-[6%] ring-1 ring-ink-100">
            {p.cover.device === "mobile" ? (
              <PhoneTrio screens={coverPhones(p)} eager interactive className="mx-auto w-full max-w-3xl pb-[4%]" />
            ) : (
              <BrowserFrame screen={p.cover} eager className="rounded-b-none" />
            )}
            {p.coverMobile && (
              <PhoneFrame screen={p.coverMobile} crop interactive tilt={{ rx: 6, ry: -20, rz: 2 }} className="absolute bottom-[-4%] right-[6%] hidden w-[18%] md:block" />
            )}
          </Reveal>
        </Container>
      </section>

      {/* Body with sticky table of contents */}
      <Container className="grid gap-12 py-16 lg:grid-cols-[220px_1fr] lg:gap-16">
        <aside className="hidden lg:block">
          <nav className="sticky top-28" aria-label="Case study sections">
            <p className="mb-4 text-xs font-bold uppercase tracking-[0.18em] text-ink-400">Case study</p>
            <ul className="space-y-1 border-l border-ink-100">
              {sections.map((s) => (
                <li key={s.id}>
                  <button
                    type="button"
                    onClick={() => scrollTo(s.id)}
                    className={cn(
                      "-ml-px block border-l-2 py-1.5 pl-4 text-left text-sm font-semibold transition-colors",
                      active === s.id ? "border-brand-500 text-brand-700" : "border-transparent text-ink-500 hover:text-ink-900",
                    )}
                  >
                    {s.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        <div className="min-w-0 space-y-24">
          <Block id="overview" n={num("overview")} title="Project Overview">
            <p className="max-w-3xl text-xl leading-relaxed text-ink-700">{cs.overview}</p>
          </Block>

          <Block id="problem" n={num("problem")} title="Problem & Solution">
            <div className="grid gap-5 md:grid-cols-2">
              <ListCard tone="problem" title="The problem" items={cs.problem} />
              <ListCard tone="solution" title="The solution" items={cs.solution} />
            </div>
          </Block>

          <Block id="role" n={num("role")} title="My Role">
            <div className="grid gap-5 md:grid-cols-[1.2fr_1fr]">
              <div className="rounded-3xl bg-white p-7 ring-1 ring-ink-100">
                <p className="text-lg font-bold text-ink-950">{cs.role.title}</p>
                <ul className="mt-5 space-y-3">
                  {cs.role.responsibilities.map((r) => (
                    <li key={r} className="flex gap-3 text-[15px] text-ink-600">
                      <Icon name="check" className="mt-0.5 size-5 shrink-0 text-brand-500" />
                      {r}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-3xl bg-ink-50 p-7 ring-1 ring-ink-100">
                <p className="text-sm font-semibold text-ink-500">Tools</p>
                <ul className="mt-4 flex flex-wrap gap-2">
                  {cs.role.tools.map((t) => (
                    <li key={t} className="rounded-full bg-white px-3.5 py-1.5 text-sm font-semibold text-ink-800 ring-1 ring-ink-200">{t}</li>
                  ))}
                </ul>
                {(cs.role.team || cs.role.duration) && (
                  <dl className="mt-6 grid grid-cols-2 gap-4 border-t border-ink-200 pt-5">
                    {cs.role.team && <Meta label="Team" value={cs.role.team} />}
                    {cs.role.duration && <Meta label="Duration" value={cs.role.duration} />}
                  </dl>
                )}
              </div>
            </div>
          </Block>

          <Block id="flow" n={num("flow")} title="User Flow">
            <ol className="flex flex-wrap items-stretch gap-3">
              {cs.userFlow.map((step, i) => (
                <li key={step} className="flex items-center gap-3">
                  <div className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 ring-1 ring-ink-100 transition hover:ring-brand-300">
                    <span className="grid size-7 place-items-center rounded-full bg-brand-50 text-xs font-bold tabular-nums text-brand-700">{i + 1}</span>
                    <span className="text-sm font-semibold text-ink-800">{step}</span>
                  </div>
                  {i < cs.userFlow.length - 1 && <Icon name="arrow-right" className="size-4 shrink-0 text-ink-300" />}
                </li>
              ))}
            </ol>
          </Block>

          {cs.wireframes.length > 0 && (
            <Block id="wireframe" n={num("wireframe")} title="Wireframe">
              <ScreenGrid screens={cs.wireframes} />
            </Block>
          )}

          <Block id="ui" n={num("ui")} title="UI Design">
            <div className="grid gap-5 lg:grid-cols-[1.3fr_1fr]">
              <ul className="space-y-4 rounded-3xl bg-white p-7 ring-1 ring-ink-100">
                {cs.uiDesign.notes.map((n) => (
                  <li key={n} className="flex gap-3 text-[15px] leading-relaxed text-ink-600">
                    <span className="mt-2 size-1.5 shrink-0 rounded-full bg-brand-500" />
                    {n}
                  </li>
                ))}
              </ul>
              <div className="space-y-5">
                {cs.uiDesign.palette && (
                  <div className="rounded-3xl bg-white p-6 ring-1 ring-ink-100">
                    <p className="text-sm font-semibold text-ink-500">Colours from the design</p>
                    <ul className="mt-4 grid grid-cols-3 gap-3">
                      {cs.uiDesign.palette.map((c) => (
                        <li key={c.hex}>
                          <span className="block h-14 rounded-xl ring-1 ring-ink-900/10" style={{ background: c.hex }} />
                          <span className="mt-2 block text-xs font-semibold text-ink-800">{c.name}</span>
                          <span className="block font-mono text-[11px] uppercase text-ink-400">{c.hex}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {cs.uiDesign.components && (
                  <div className="rounded-3xl bg-ink-50 p-6 ring-1 ring-ink-100">
                    <p className="text-sm font-semibold text-ink-500">Key components</p>
                    <ul className="mt-4 flex flex-wrap gap-2">
                      {cs.uiDesign.components.map((c) => (
                        <li key={c} className="rounded-lg bg-white px-3 py-1.5 text-sm font-medium text-ink-700 ring-1 ring-ink-200">{c}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </Block>

          <Block id="screens" n={num("screens")} title="Final Screens" note="Click a screen to view it full size.">
            <ScreenGrid screens={cs.finalScreens} onOpen={setLightbox} />
          </Block>

          <Block id="prototype" n={num("prototype")} title="Prototype">
            <div className="relative overflow-hidden rounded-[32px] bg-ink-950 p-8 text-white sm:p-12">
              <div className="pointer-events-none absolute -right-20 -top-20 size-80 rounded-full bg-brand-500/30 blur-3xl" aria-hidden="true" />
              <div className="relative grid gap-8 md:grid-cols-[1.3fr_1fr] md:items-center">
                <div>
                  <span className="grid size-12 place-items-center rounded-2xl bg-white/10"><Icon name="play" /></span>
                  <h3 className="mt-6 text-2xl font-extrabold tracking-tight sm:text-3xl">Try the interactive prototype</h3>
                  <p className="mt-3 max-w-md text-white/70">
                    {p.prototypeUrl
                      ? "Click through the main flow in Figma, exactly as it was presented to stakeholders."
                      : "The prototype link will appear here. Add prototypeUrl in projects.ts."}
                  </p>
                </div>
                <div className="flex flex-col gap-3">
                  {p.prototypeUrl ? (
                    <ButtonLink href={p.prototypeUrl} target="_blank" rel="noreferrer" size="lg" icon="arrow-up-right" variant="light">Open prototype</ButtonLink>
                  ) : (
                    <span className="inline-flex h-13 items-center justify-center rounded-full border border-dashed border-white/25 px-6 text-sm font-semibold text-white/50">Prototype link coming soon</span>
                  )}
                  {p.figmaUrl && (
                    <ButtonLink href={p.figmaUrl} target="_blank" rel="noreferrer" size="lg" variant="outline-light" icon="figma" iconPosition="left">View design file</ButtonLink>
                  )}
                </div>
              </div>
            </div>
          </Block>
        </div>
      </Container>

      {/* Next project */}
      <section className="border-t border-ink-100">
        <Container>
          <a href={paths.caseStudy(next.slug)} className="group flex flex-col gap-4 py-14 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-sm font-semibold text-ink-400">Next project</p>
              <p className="mt-2 text-3xl font-extrabold tracking-tight text-ink-950 transition-colors group-hover:text-brand-600 sm:text-5xl">{next.title}</p>
            </div>
            <span className="grid size-16 place-items-center rounded-full bg-ink-50 text-ink-900 ring-1 ring-ink-100 transition-all duration-300 group-hover:bg-brand-500 group-hover:text-white">
              <Icon name="arrow-right" className="size-6 transition-transform group-hover:translate-x-1" />
            </span>
          </a>
        </Container>
      </section>

      <ContactCTA />
      <Lightbox screens={cs.finalScreens} index={lightbox} onChange={setLightbox} projectTitle={p.title} />
    </>
  );
}

function Block({ id, n, title, note, children }: { id: string; n: string; title: string; note?: string; children: ReactNode }) {
  return (
    <section id={id} className="scroll-mt-28">
      <Reveal>
        <div className="mb-8 flex flex-wrap items-baseline justify-between gap-3 border-b border-ink-100 pb-5">
          <h2 className="flex items-baseline gap-4 text-2xl font-extrabold tracking-tight text-ink-950 sm:text-3xl">
            <span className="text-sm font-bold tabular-nums text-brand-500">{n}</span>
            {title}
          </h2>
          {note && <p className="text-sm text-ink-400">{note}</p>}
        </div>
        {children}
      </Reveal>
    </section>
  );
}

function ListCard({ tone, title, items }: { tone: "problem" | "solution"; title: string; items: string[] }) {
  const solution = tone === "solution";
  return (
    <div className={cn("rounded-3xl p-7 ring-1", solution ? "bg-brand-50/60 ring-brand-100" : "bg-white ring-ink-100")}>
      <p className={cn("text-xs font-bold uppercase tracking-[0.16em]", solution ? "text-brand-700" : "text-ink-400")}>{title}</p>
      <ul className="mt-5 space-y-4">
        {items.map((t) => (
          <li key={t} className="flex gap-3 text-[15px] leading-relaxed text-ink-700">
            <span className={cn("mt-2 size-1.5 shrink-0 rounded-full", solution ? "bg-brand-500" : "bg-ink-300")} />
            {t}
          </li>
        ))}
      </ul>
    </div>
  );
}

function ScreenGrid({ screens, onOpen }: { screens: Screen[]; onOpen?: (i: number) => void }) {
  const desktop = screens.map((s, i) => ({ s, i })).filter(({ s }) => s.device === "desktop");
  const mobile = screens.map((s, i) => ({ s, i })).filter(({ s }) => s.device === "mobile");
  const Item = ({ s, i }: { s: Screen; i: number }) => {
    const inner = <DeviceFrame screen={s} interactive tilt={s.device === "mobile" ? { rx: 4, ry: -10 } : undefined} />;
    return (
      <figure className="group">
        {onOpen ? (
          <button type="button" onClick={() => onOpen(i)} className="relative block w-full cursor-zoom-in text-left transition-transform duration-500 ease-[var(--ease-out-soft)] hover:-translate-y-1" aria-label={`View ${s.title} full size`}>
            {inner}
            <span className="absolute right-3 top-11 grid size-9 place-items-center rounded-full bg-white/95 text-ink-800 opacity-0 shadow ring-1 ring-ink-100 transition-opacity duration-300 group-hover:opacity-100">
              <Icon name="expand" className="size-4" />
            </span>
          </button>
        ) : (
          inner
        )}
        <figcaption className="mt-3 flex items-baseline gap-2 text-sm text-ink-500">
          <span className="font-bold tabular-nums text-brand-500">{String(i + 1).padStart(2, "0")}</span>
          {s.title}
        </figcaption>
      </figure>
    );
  };
  return (
    <div className="space-y-10">
      {desktop.length > 0 && (
        <div className="grid gap-x-6 gap-y-10 md:grid-cols-2">
          {desktop.map(({ s, i }) => <Item key={i} s={s} i={i} />)}
        </div>
      )}
      {mobile.length > 0 && (
        <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
          {mobile.map(({ s, i }) => <Item key={i} s={s} i={i} />)}
        </div>
      )}
    </div>
  );
}

function Meta({ label, value, muted }: { label: string; value: string; muted?: boolean }) {
  return (
    <div>
      <dt className="text-xs font-semibold text-ink-400">{label}</dt>
      <dd className={cn("mt-1 text-[15px] font-bold", muted ? "text-ink-300" : "text-ink-900")}>{value}</dd>
    </div>
  );
}

function useActiveSection() {
  const [active, setActive] = useState<string>(SECTIONS[0].id);
  useEffect(() => {
    const els = SECTIONS.map((s) => document.getElementById(s.id)).filter(Boolean) as HTMLElement[];
    if (!("IntersectionObserver" in window)) return;
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setActive(visible[0].target.id);
      },
      { rootMargin: "-20% 0px -60% 0px" },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
  return active;
}

function NotFound() {
  return (
    <section className="grid min-h-[70vh] place-items-center pt-24">
      <div className="text-center">
        <p className="text-sm font-bold text-brand-600">Project not found</p>
        <h1 className="mt-3 text-4xl font-extrabold text-ink-950">This case study doesn't exist yet.</h1>
        <ButtonLink href={paths.work} className="mt-8" icon="arrow-right">Back to all projects</ButtonLink>
      </div>
    </section>
  );
}
