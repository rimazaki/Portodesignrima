import { process, profile } from "../data/profile";
import { getProject, projects } from "../data/projects";
import { paths } from "../lib/router";
import { ButtonLink } from "../components/Button";
import { Container } from "../components/Container";
import { ContactCTA } from "../components/ContactCTA";
import { BrowserFrame, PhoneFrame } from "../components/DeviceFrame";
import { Icon } from "../components/Icon";
import { ProjectCard } from "../components/ProjectCard";
import { Reveal } from "../components/Reveal";
import { SectionHeading } from "../components/SectionHeading";
import { SkillsGrid } from "../components/SkillsGrid";
import { Avatar } from "../components/Avatar";

export function Home() {
  return (
    <>
      <Hero />
      <Specializations />
      <SelectedWork />
      <AboutPreview />
      <section className="bg-ink-50/70 py-20 sm:py-28">
        <Container>
          <SectionHeading
            eyebrow="My skills"
            title="From research to developer handoff."
            description="The full design cycle for complex products, done with care at every step."
            className="mb-12"
          />
          <SkillsGrid />
        </Container>
      </section>
      <Process />
      <ContactCTA />
    </>
  );
}

function Hero() {
  const crm = getProject("crm-app")!;
  const erp = getProject("erp-app")!;
  const hcms = getProject("hcms-app")!;
  return (
    <section className="relative overflow-hidden pb-16 pt-32 sm:pb-24 sm:pt-40">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[640px] bg-[radial-gradient(60%_60%_at_70%_20%,var(--color-brand-50),transparent_70%)]" aria-hidden="true" />
      <Container className="relative grid items-center gap-14 lg:grid-cols-[1.05fr_1fr] lg:gap-10">
        <div>
          <p className="animate-fade-up inline-flex items-center gap-2 rounded-full bg-white px-3.5 py-1.5 text-xs font-semibold text-ink-700 shadow-sm ring-1 ring-ink-100">
            <span className="relative flex size-2">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex size-2 rounded-full bg-emerald-500" />
            </span>
            Open to UI/UX Designer roles
          </p>
          <h1 className="animate-fade-up mt-7 text-[38px] font-extrabold leading-[1.06] tracking-[-0.03em] text-ink-950 [animation-delay:80ms] sm:text-[52px] xl:text-[58px]">
            Hi, I'm {profile.firstName}.
            <span className="mt-2 block text-ink-400">
              I design <span className="text-brand-500">enterprise software</span> that makes complex operations feel simple.
            </span>
          </h1>
          <p className="animate-fade-up mt-7 max-w-xl text-lg leading-relaxed text-ink-500 [animation-delay:160ms]">{profile.intro}</p>
          <div className="animate-fade-up mt-9 flex flex-col gap-3 [animation-delay:240ms] sm:flex-row">
            <ButtonLink href={paths.work} size="lg" icon="arrow-right">View My Work</ButtonLink>
            <ButtonLink href={profile.cvUrl} download size="lg" variant="secondary" icon="download">Download CV</ButtonLink>
          </div>
          <dl className="animate-fade-up mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-ink-100 pt-7 [animation-delay:320ms]">
            {[
              [profile.experienceYears, "Years of experience"],
              [String(projects.length), "Case studies"],
              ["Web + Mobile", "Platforms"],
            ].map(([v, l]) => (
              <div key={l}>
                <dt className="sr-only">{l}</dt>
                <dd className="text-2xl font-extrabold tracking-tight text-ink-950 sm:text-3xl">{v}</dd>
                <dd className="mt-1 text-xs font-medium text-ink-500 sm:text-sm">{l}</dd>
              </div>
            ))}
          </dl>
        </div>

        {/* Mockup stack built from real Figma screens */}
        <div className="animate-fade-up relative mx-auto w-full max-w-[640px] [animation-delay:200ms] lg:mr-0">
          <div className="bg-dots absolute -inset-6 rounded-[40px] opacity-70" aria-hidden="true" />
          <a href={paths.caseStudy(erp.slug)} className="absolute -left-2 top-0 hidden w-[62%] rotate-[-4deg] opacity-90 transition-all duration-700 hover:rotate-[-2deg] hover:opacity-100 sm:block" aria-label="ERP App case study">
            <BrowserFrame screen={erp.cover} crop eager />
          </a>
          <a href={paths.caseStudy(crm.slug)} className="relative ml-auto block w-full transition-transform duration-700 hover:-translate-y-1 sm:mt-24 sm:w-[86%]" aria-label="CRM App case study">
            <BrowserFrame screen={crm.cover} crop url="crm.sales-portal.app" eager />
          </a>
          <a href={paths.caseStudy(hcms.slug)} className="animate-float absolute -bottom-10 -left-1 w-[28%] sm:left-[4%] sm:w-[24%]" aria-label="HCMS App case study">
            <PhoneFrame screen={hcms.coverMobile!} eager crop interactive tilt={{ rx: 8, ry: 22, rz: -3 }} />
          </a>
          <div className="absolute -right-2 -top-4 hidden rounded-2xl bg-white px-4 py-3 shadow-xl ring-1 ring-ink-100 sm:block lg:-right-6">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-400">Real work</p>
            <p className="text-sm font-bold text-ink-900">ERP · CRM · HCMS</p>
          </div>
        </div>
      </Container>
    </section>
  );
}

function Specializations() {
  const items = [...profile.specializations, ...profile.specializations];
  return (
    <section aria-label="Specializations" className="border-y border-ink-100 bg-white py-6">
      <div className="relative overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_10%,black_90%,transparent)]">
        <ul className="animate-marquee flex w-max gap-10 hover:[animation-play-state:paused]">
          {items.map((s, i) => (
            <li key={i} className="flex items-center gap-10 whitespace-nowrap text-lg font-bold text-ink-300 sm:text-xl" aria-hidden={i >= profile.specializations.length}>
              {s}
              <Icon name="sparkles" className="size-4 text-brand-300" />
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function SelectedWork() {
  const featured = projects.filter((p) => p.featured);
  const others = projects.filter((p) => !p.featured);
  return (
    <section className="py-20 sm:py-28" id="selected-work">
      <Container>
        <SectionHeading
          eyebrow="Selected work"
          title="Enterprise products, designed end to end."
          description="A selection of the systems I've designed. Open a project to see the problem, the flow and the final screens."
          action={<ButtonLink href={paths.work} variant="secondary" icon="arrow-right">View all projects</ButtonLink>}
          className="mb-12"
        />
        <div className="grid gap-6 lg:grid-cols-2">
          {featured.map((p, i) => (
            <Reveal key={p.slug} delay={i * 90} className={i === 0 ? "lg:col-span-2" : ""}>
              {i === 0 ? <FeaturedWide slug={p.slug} /> : <ProjectCard project={p} size="lg" />}
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-10 rounded-3xl bg-ink-50 p-6 ring-1 ring-ink-100 sm:p-8">
          <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
            <p className="text-sm font-semibold text-ink-500">More case studies</p>
            <ul className="flex flex-wrap gap-2">
              {others.map((p) => (
                <li key={p.slug}>
                  <a href={paths.caseStudy(p.slug)} className="group inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-sm font-semibold text-ink-800 ring-1 ring-ink-200 transition hover:text-brand-700 hover:ring-brand-300">
                    {p.title}
                    <Icon name="arrow-up-right" className="size-3.5 text-ink-400 transition group-hover:text-brand-600" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}

/** First featured project as a wide split card. */
function FeaturedWide({ slug }: { slug: string }) {
  const p = getProject(slug)!;
  return (
    <a href={paths.caseStudy(p.slug)} className="group grid overflow-hidden rounded-[32px] bg-brand-800 ring-1 ring-brand-900 transition-all duration-500 hover:shadow-[0_50px_90px_-45px_rgba(0,90,111,0.7)] lg:grid-cols-[0.9fr_1.3fr]">
      <div className="flex flex-col gap-5 p-8 text-white sm:p-10">
        <span className="text-xs font-bold uppercase tracking-[0.18em] text-brand-200">{p.category} · {p.industry}</span>
        <h3 className="text-3xl font-extrabold tracking-tight sm:text-4xl">{p.title}</h3>
        <p className="text-base leading-relaxed text-brand-100">{p.summary}</p>
        <div className="flex flex-wrap gap-2">
          {p.tags.map((t) => (
            <span key={t} className="rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-white ring-1 ring-white/15">{t}</span>
          ))}
        </div>
        <span className="mt-auto inline-flex items-center gap-2 pt-4 text-sm font-bold text-white">
          Read case study
          <Icon name="arrow-right" className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
        </span>
      </div>
      <div className="relative min-h-[260px] overflow-hidden bg-brand-700/40 pl-8 pt-8 sm:pl-12 sm:pt-12">
        <BrowserFrame screen={p.cover} crop panOnHover className="rounded-b-none rounded-r-none transition-transform duration-700 ease-[var(--ease-out-soft)] group-hover:-translate-x-2 group-hover:-translate-y-2" />
      </div>
    </a>
  );
}

function AboutPreview() {
  return (
    <section className="pb-20 sm:pb-28">
      <Container className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
        <Reveal className="relative mx-auto w-full max-w-sm">
          <Avatar className="aspect-[4/5] w-full rounded-[32px]" />
          <div className="absolute -bottom-5 -right-3 rounded-2xl bg-white px-5 py-4 shadow-xl ring-1 ring-ink-100 sm:-right-8">
            <p className="text-3xl font-extrabold text-brand-500">{profile.experienceYears}</p>
            <p className="text-xs font-semibold text-ink-500">years designing products</p>
          </div>
        </Reveal>
        <div>
          <SectionHeading eyebrow="About me" title="Designing for the people who run the operation." />
          <Reveal delay={80}>
            <p className="mt-6 text-lg leading-relaxed text-ink-500">{profile.bio[0]}</p>
            <p className="mt-4 text-lg leading-relaxed text-ink-500">{profile.bio[1]}</p>
          </Reveal>
          <Reveal delay={140} className="mt-8">
            <p className="mb-3 text-sm font-semibold text-ink-900">Tools I use every day</p>
            <ul className="flex flex-wrap gap-2">
              {profile.tools.map((t) => (
                <li key={t.name} className="inline-flex items-center gap-2 rounded-full bg-brand-50 px-4 py-2 text-sm font-semibold text-brand-800">
                  {t.name === "Figma" || t.name === "Figma AI" ? <Icon name="figma" className="size-4" /> : <Icon name="sparkles" className="size-4" />}
                  {t.name}
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={200} className="mt-9">
            <ButtonLink href={paths.about} variant="secondary" icon="arrow-right">More about me</ButtonLink>
          </Reveal>
        </div>
      </Container>
    </section>
  );
}

function Process() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionHeading eyebrow="How I work" title="A clear process, every project." className="mb-12" />
        <ol className="grid gap-px overflow-hidden rounded-3xl bg-ink-100 ring-1 ring-ink-100 sm:grid-cols-2 lg:grid-cols-5">
          {process.map((s, i) => (
            <Reveal as="li" key={s.step} delay={i * 70} className="group bg-white p-6 transition-colors duration-300 hover:bg-brand-50/50">
              <span className="text-sm font-bold tabular-nums text-brand-500">{s.step}</span>
              <h3 className="mt-8 text-lg font-bold text-ink-950">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-500">{s.text}</p>
            </Reveal>
          ))}
        </ol>
      </Container>
    </section>
  );
}
