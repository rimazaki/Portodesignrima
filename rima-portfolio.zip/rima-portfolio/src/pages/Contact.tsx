import { useState, type FormEvent, type ReactNode } from "react";
import { profile } from "../data/profile";
import { cn } from "../lib/cn";
import { ButtonLink } from "../components/Button";
import { Container } from "../components/Container";
import { Icon, type IconName } from "../components/Icon";
import { Reveal } from "../components/Reveal";

export function Contact() {
  const [copied, setCopied] = useState(false);

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(profile.email);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <section className="relative overflow-hidden pb-24 pt-32 sm:pt-40">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[520px] bg-[radial-gradient(50%_60%_at_20%_0%,var(--color-brand-50),transparent_70%)]" aria-hidden="true" />
      <Container className="relative grid gap-14 lg:grid-cols-[1fr_1.1fr]">
        <div>
          <p className="animate-fade-up mb-4 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em] text-brand-600">
            <span className="h-px w-6 bg-brand-500" aria-hidden="true" />
            Contact
          </p>
          <h1 className="animate-fade-up text-4xl font-extrabold leading-[1.05] tracking-tight text-ink-950 [animation-delay:80ms] sm:text-6xl">
            Let's work together.
          </h1>
          <p className="animate-fade-up mt-6 max-w-lg text-lg leading-relaxed text-ink-500 [animation-delay:160ms]">
            Hiring a UI/UX Designer, or need help with a complex product? Send me a message. I usually reply within 1–2 working days.
          </p>

          <ul className="mt-10 space-y-3">
            <ContactRow icon="mail" label="Email" value={profile.email} href={`mailto:${profile.email}`} delay={0}>
              <button
                type="button"
                onClick={copyEmail}
                className="inline-flex h-9 items-center gap-1.5 rounded-full bg-ink-50 px-3 text-xs font-semibold text-ink-700 ring-1 ring-ink-200 transition hover:text-brand-700 hover:ring-brand-300"
                aria-live="polite"
              >
                <Icon name={copied ? "check" : "copy"} className="size-4" />
                {copied ? "Copied" : "Copy"}
              </button>
            </ContactRow>
            <ContactRow icon="linkedin" label="LinkedIn" value="Connect on LinkedIn" href={profile.linkedin} external delay={70} />
            <ContactRow icon="download" label="Curriculum Vitae" value="Download CV (PDF)" href={profile.cvUrl} download delay={140} />
            <ContactRow icon="figma" label="Figma" value="Portfolio documentation" href={profile.figma} external delay={210} />
          </ul>
        </div>

        <Reveal delay={120}>
          <ContactForm />
        </Reveal>
      </Container>
    </section>
  );
}

function ContactRow({
  icon, label, value, href, external, download, delay, children,
}: {
  icon: IconName; label: string; value: string; href: string; external?: boolean; download?: boolean; delay: number; children?: ReactNode;
}) {
  return (
    <Reveal as="li" delay={delay} className="flex items-center gap-3 rounded-2xl bg-white p-3 pr-4 ring-1 ring-ink-100 transition hover:ring-brand-200">
      <a
        href={href}
        target={external ? "_blank" : undefined}
        rel={external ? "noreferrer" : undefined}
        download={download || undefined}
        className="group flex min-w-0 flex-1 items-center gap-4"
      >
        <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-600 transition-colors group-hover:bg-brand-500 group-hover:text-white">
          <Icon name={icon} />
        </span>
        <span className="min-w-0">
          <span className="block text-xs font-semibold text-ink-400">{label}</span>
          <span className="block truncate font-bold text-ink-900 group-hover:text-brand-700">{value}</span>
        </span>
      </a>
      {children ?? <Icon name="arrow-up-right" className="size-5 shrink-0 text-ink-300" />}
    </Reveal>
  );
}

/** No backend needed: the form composes an email in the visitor's mail app. */
function ContactForm() {
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = String(data.get("name") ?? "").trim();
    const email = String(data.get("email") ?? "").trim();
    const company = String(data.get("company") ?? "").trim();
    const message = String(data.get("message") ?? "").trim();
    const next: Record<string, string> = {};
    if (!name) next.name = "Please enter your name.";
    if (!/^\S+@\S+\.\S+$/.test(email)) next.email = "Please enter a valid email address.";
    if (message.length < 10) next.message = "Please write a short message (at least 10 characters).";
    setErrors(next);
    if (Object.keys(next).length) return;

    const subject = encodeURIComponent(`Portfolio enquiry from ${name}${company ? ` (${company})` : ""}`);
    const body = encodeURIComponent(`${message}\n\n${name}\n${email}${company ? `\n${company}` : ""}`);
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
    setSent(true);
  };

  if (sent) {
    return (
      <div className="flex h-full flex-col items-start justify-center rounded-[32px] bg-white p-8 ring-1 ring-ink-100 sm:p-10">
        <span className="grid size-14 place-items-center rounded-2xl bg-brand-500 text-white"><Icon name="check" className="size-7" /></span>
        <h2 className="mt-6 text-2xl font-extrabold text-ink-950">Your email is ready.</h2>
        <p className="mt-3 text-ink-500">
          Your mail app should have opened with the message filled in. Press send there. If nothing opened, email me directly at{" "}
          <span className="font-semibold text-ink-800">{profile.email}</span>.
        </p>
        <button type="button" onClick={() => setSent(false)} className="mt-8 text-sm font-semibold text-brand-600 hover:text-brand-700">Write another message</button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="rounded-[32px] bg-white p-6 shadow-[0_40px_80px_-50px_rgba(0,90,111,0.45)] ring-1 ring-ink-100 sm:p-10">
      <h2 className="text-2xl font-extrabold tracking-tight text-ink-950">Contact me</h2>
      <p className="mt-2 text-sm text-ink-500">Fields marked * are required.</p>
      <div className="mt-8 grid gap-5 sm:grid-cols-2">
        <Field id="name" label="Your name *" error={errors.name} autoComplete="name" />
        <Field id="email" label="Email *" type="email" error={errors.email} autoComplete="email" />
        <Field id="company" label="Company" className="sm:col-span-2" autoComplete="organization" />
        <Field id="message" label="Message *" textarea className="sm:col-span-2" error={errors.message} placeholder="Tell me about the role or project…" />
      </div>
      <button
        type="submit"
        className="group mt-8 inline-flex h-13 w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-7 text-[15px] font-semibold text-white shadow-[0_10px_30px_-12px_rgba(0,128,157,0.7)] transition hover:bg-brand-600 active:scale-[0.99]"
      >
        Send message
        <Icon name="send" className="size-[18px] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
      </button>
      <p className="mt-4 text-center text-xs text-ink-400">Opens your email app with the message ready to send.</p>
      <div className="mt-6 border-t border-ink-100 pt-6 text-center">
        <ButtonLink href={profile.cvUrl} download variant="ghost" icon="download">Or download my CV</ButtonLink>
      </div>
    </form>
  );
}

function Field({
  id, label, type = "text", textarea, error, className, placeholder, autoComplete,
}: {
  id: string; label: string; type?: string; textarea?: boolean; error?: string; className?: string; placeholder?: string; autoComplete?: string;
}) {
  const cls = cn(
    "w-full rounded-2xl bg-ink-50 px-4 py-3.5 text-[15px] text-ink-900 ring-1 transition placeholder:text-ink-400 focus:bg-white focus:outline-none focus:ring-2",
    error ? "ring-rose-300 focus:ring-rose-400" : "ring-ink-100 focus:ring-brand-400",
  );
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-2 block text-sm font-semibold text-ink-800">{label}</label>
      {textarea ? (
        <textarea id={id} name={id} rows={5} className={cn(cls, "resize-y")} placeholder={placeholder} aria-invalid={!!error} aria-describedby={error ? `${id}-error` : undefined} />
      ) : (
        <input id={id} name={id} type={type} className={cls} placeholder={placeholder} autoComplete={autoComplete} aria-invalid={!!error} aria-describedby={error ? `${id}-error` : undefined} />
      )}
      {error && <p id={`${id}-error`} className="mt-1.5 text-xs font-medium text-rose-600">{error}</p>}
    </div>
  );
}
