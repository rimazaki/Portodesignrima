import { useMemo, useState } from "react";
import { categories, projects } from "../data/projects";
import { cn } from "../lib/cn";
import { Container } from "../components/Container";
import { ContactCTA } from "../components/ContactCTA";
import { ProjectCard } from "../components/ProjectCard";
import { Reveal } from "../components/Reveal";

export function Projects() {
  const [filter, setFilter] = useState("All");
  const list = useMemo(() => (filter === "All" ? projects : projects.filter((p) => p.category === filter)), [filter]);

  return (
    <>
      <section className="relative overflow-hidden pb-10 pt-32 sm:pt-40">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-96 bg-[radial-gradient(50%_70%_at_20%_0%,var(--color-brand-50),transparent_70%)]" aria-hidden="true" />
        <Container className="relative">
          <p className="animate-fade-up mb-4 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em] text-brand-600">
            <span className="h-px w-6 bg-brand-500" aria-hidden="true" />
            My projects
          </p>
          <h1 className="animate-fade-up max-w-3xl text-4xl font-extrabold leading-[1.05] tracking-tight text-ink-950 [animation-delay:80ms] sm:text-6xl">
            {projects.length} products, from enterprise systems to everyday apps.
          </h1>
          <p className="animate-fade-up mt-6 max-w-2xl text-lg leading-relaxed text-ink-500 [animation-delay:160ms]">
            ERP, CRM and HCMS suites, oil & gas engineering tools, fintech and public-service mobile apps, admin panels, a marketing website and a design system. Each project opens a full case study.
          </p>

          <div className="animate-fade-up mt-10 flex flex-wrap gap-2 [animation-delay:240ms]" role="group" aria-label="Filter projects by category">
            {categories.map((c) => {
              const count = c === "All" ? projects.length : projects.filter((p) => p.category === c).length;
              const active = c === filter;
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => setFilter(c)}
                  aria-pressed={active}
                  className={cn(
                    "inline-flex items-center gap-2 rounded-full px-4 py-2.5 text-sm font-semibold transition-all duration-300",
                    active ? "bg-ink-950 text-white" : "bg-white text-ink-600 ring-1 ring-ink-200 hover:text-ink-950 hover:ring-ink-300",
                  )}
                >
                  {c}
                  <span className={cn("rounded-full px-1.5 text-[11px] tabular-nums", active ? "bg-white/15" : "bg-ink-100")}>{count}</span>
                </button>
              );
            })}
          </div>
        </Container>
      </section>

      <section className="pb-8">
        <Container>
          <ul className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {list.map((p, i) => (
              <Reveal as="li" key={p.slug} delay={(i % 3) * 80}>
                <ProjectCard project={p} index={projects.indexOf(p)} />
              </Reveal>
            ))}
          </ul>
        </Container>
      </section>
      <ContactCTA />
    </>
  );
}
