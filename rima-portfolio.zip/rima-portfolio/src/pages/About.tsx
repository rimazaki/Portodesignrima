import { process, profile } from "../data/profile";
import { paths } from "../lib/router";
import { Avatar } from "../components/Avatar";
import { ButtonLink } from "../components/Button";
import { Container } from "../components/Container";
import { ContactCTA } from "../components/ContactCTA";
import { Icon } from "../components/Icon";
import { Reveal } from "../components/Reveal";
import { SectionHeading } from "../components/SectionHeading";
import { SkillsGrid } from "../components/SkillsGrid";

export function About() {
  return (
    <>
      <section className="relative overflow-hidden pb-20 pt-32 sm:pt-40">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[520px] bg-[radial-gradient(50%_60%_at_80%_10%,var(--color-brand-50),transparent_70%)]" aria-hidden="true" />
        <Container className="relative grid gap-14 lg:grid-cols-[1.25fr_0.75fr] lg:items-start">
          <div>
            <p className="animate-fade-up mb-4 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em] text-brand-600">
              <span className="h-px w-6 bg-brand-500" aria-hidden="true" />
              About me
            </p>
            <h1 className="animate-fade-up text-4xl font-extrabold leading-[1.05] tracking-tight text-ink-950 [animation-delay:80ms] sm:text-6xl">
              {profile.name}
            </h1>
            <p className="animate-fade-up mt-3 text-xl font-semibold text-ink-400 [animation-delay:120ms] sm:text-2xl">
              {profile.role} · {profile.experienceYears} years
            </p>
            <div className="animate-fade-up mt-8 space-y-5 text-lg leading-relaxed text-ink-600 [animation-delay:180ms]">
              {profile.bio.map((p) => <p key={p}>{p}</p>)}
            </div>
            <div className="animate-fade-up mt-10 flex flex-col gap-3 [animation-delay:240ms] sm:flex-row">
              <ButtonLink href={profile.cvUrl} download size="lg" icon="download">Download CV</ButtonLink>
              <ButtonLink href={paths.contact} size="lg" variant="secondary" icon="arrow-right">Get in touch</ButtonLink>
            </div>
          </div>
          <div className="animate-fade-up space-y-5 [animation-delay:160ms]">
            <Avatar className="aspect-[4/5] w-full rounded-[32px]" />
            <div className="flex items-center gap-3 rounded-2xl bg-white p-4 ring-1 ring-ink-100">
              <span className="grid size-10 place-items-center rounded-xl bg-brand-50 text-brand-600"><Icon name="map-pin" /></span>
              <p className="text-sm font-semibold text-ink-700">{profile.location}</p>
            </div>
          </div>
        </Container>
      </section>

      {/* Specialization */}
      <section className="bg-ink-50/70 py-20 sm:py-24">
        <Container className="grid gap-12 lg:grid-cols-2">
          <div>
            <SectionHeading eyebrow="Specialization" title="Where I do my best work." />
            <Reveal delay={80}>
              <ul className="mt-8 flex flex-wrap gap-2.5">
                {profile.specializations.map((s) => (
                  <li key={s} className="rounded-full bg-white px-4 py-2.5 text-sm font-semibold text-ink-800 ring-1 ring-ink-200">{s}</li>
                ))}
              </ul>
            </Reveal>
          </div>
          <div>
            <SectionHeading eyebrow="Tools" title="My everyday toolkit." />
            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {profile.tools.map((t, i) => (
                <Reveal as="li" key={t.name} delay={i * 70} className="rounded-2xl bg-white p-5 ring-1 ring-ink-100">
                  <div className="flex items-center gap-3">
                    <span className="grid size-10 place-items-center rounded-xl bg-brand-500 text-white">
                      <Icon name={t.name.startsWith("Figma") ? "figma" : "sparkles"} className="size-5" />
                    </span>
                    <p className="font-bold text-ink-950">{t.name}</p>
                  </div>
                  <p className="mt-3 text-sm text-ink-500">{t.note}</p>
                </Reveal>
              ))}
            </ul>
          </div>
        </Container>
      </section>

      {/* Experience */}
      <section className="py-20 sm:py-28">
        <Container className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
          <SectionHeading eyebrow="Experience" title="Professional experience." description={`${profile.experienceYears} years designing web and mobile products for enterprise teams.`} />
          <ol className="relative space-y-6 border-l border-ink-200 pl-8">
            {profile.experience.map((e, i) => (
              <Reveal as="li" key={i} delay={i * 80} className="relative">
                <span className="absolute -left-[39px] top-2 size-3.5 rounded-full border-[3px] border-white bg-brand-500 ring-1 ring-brand-200" aria-hidden="true" />
                <div className="rounded-3xl bg-white p-6 ring-1 ring-ink-100">
                  <p className="text-sm font-semibold tabular-nums text-brand-600">{e.period}</p>
                  <h3 className="mt-2 text-xl font-bold text-ink-950">{e.role}</h3>
                  <p className="text-sm font-semibold text-ink-500">{e.company}</p>
                  <p className="mt-3 text-[15px] leading-relaxed text-ink-600">{e.summary}</p>
                </div>
              </Reveal>
            ))}
          </ol>
        </Container>
      </section>

      {/* Skills */}
      <section className="bg-ink-50/70 py-20 sm:py-28">
        <Container>
          <SectionHeading eyebrow="My skills" title="What I bring to a product team." className="mb-12" />
          <SkillsGrid />
        </Container>
      </section>

      {/* Process */}
      <section className="py-20 sm:py-28">
        <Container>
          <SectionHeading eyebrow="How I work" title="A clear process, every project." className="mb-12" />
          <ol className="grid gap-px overflow-hidden rounded-3xl bg-ink-100 ring-1 ring-ink-100 sm:grid-cols-2 lg:grid-cols-5">
            {process.map((s, i) => (
              <Reveal as="li" key={s.step} delay={i * 70} className="bg-white p-6">
                <span className="text-sm font-bold tabular-nums text-brand-500">{s.step}</span>
                <h3 className="mt-8 text-lg font-bold text-ink-950">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-500">{s.text}</p>
              </Reveal>
            ))}
          </ol>
        </Container>
      </section>

      <ContactCTA />
    </>
  );
}
