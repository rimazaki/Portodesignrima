import { useSyncExternalStore } from "react";

/**
 * Tiny hash router, no dependency needed.
 * Hash URLs (#work, #case-crm-app) work on every static host without server rewrites.
 */
export type Route =
  | { name: "home" }
  | { name: "work" }
  | { name: "case"; slug: string }
  | { name: "about" }
  | { name: "contact" };

export const paths = {
  home: "#home",
  work: "#work",
  about: "#about",
  contact: "#contact",
  caseStudy: (slug: string) => `#case-${slug}`,
};

export function parseHash(hash: string): Route {
  const h = hash.replace(/^#\/?/, "");
  if (h === "work" || h === "projects") return { name: "work" };
  if (h === "about") return { name: "about" };
  if (h === "contact") return { name: "contact" };
  if (h.startsWith("case-")) return { name: "case", slug: h.slice(5) };
  return { name: "home" };
}

const subscribe = (cb: () => void) => {
  window.addEventListener("hashchange", cb);
  return () => window.removeEventListener("hashchange", cb);
};

export function useHash() {
  return useSyncExternalStore(subscribe, () => window.location.hash, () => "");
}

export function useRoute(): Route {
  return parseHash(useHash());
}

export function navigate(to: string) {
  if (window.location.hash === to) window.scrollTo({ top: 0, behavior: "smooth" });
  else window.location.hash = to;
}

export function isActive(route: Route, href: string) {
  const target = parseHash(href);
  if (target.name === "work") return route.name === "work" || route.name === "case";
  return target.name === route.name;
}
