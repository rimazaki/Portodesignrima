/**
 * ─────────────────────────────────────────────────────────────
 *  PROJECTS: edit this file to add screenshots, Figma links and copy.
 *
 *  How to replace a placeholder with your real design:
 *   1. Export the frame from Figma (PNG/WebP, 1x or 2x).
 *   2. Save it in /public/images/projects/<project-slug>/  e.g. /public/images/projects/auth-system/login.webp
 *   3. Set `src: "images/projects/auth-system/login.webp"` on the screen below.
 *      A screen without `src` shows a neutral placeholder mockup.
 *   4. Paste your Figma file / prototype link into `figmaUrl` / `prototypeUrl`.
 *
 *  Screens are always shown exactly as exported. The site never recolours or crops your design
 *  except for the card thumbnails, which show the top of the first screen.
 * ─────────────────────────────────────────────────────────────
 */

export type Device = "desktop" | "mobile";

export type Screen = {
  title: string;
  device: Device;
  /** Path inside /public, e.g. "images/projects/crm-app/dashboard.webp". Leave empty for a placeholder. */
  src?: string;
  caption?: string;
  /** Very long page (landing page, documentation). Shown capped with a fade; full length in the viewer. */
  tall?: boolean;
};

export type Swatch = { name: string; hex: string };

export type Project = {
  slug: string;
  title: string;
  category: string;
  industry?: string;
  platform: string;
  year?: string;
  summary: string;
  tags: string[];
  featured?: boolean;
  /** Link to the Figma design file or page. */
  figmaUrl?: string;
  /** Link to the Figma prototype (Present mode link). */
  prototypeUrl?: string;
  /** Desktop + optional mobile screen used on cards and the case-study hero. */
  cover: Screen;
  coverMobile?: Screen;
  caseStudy: {
    overview: string;
    problem: string[];
    solution: string[];
    role: { title: string; responsibilities: string[]; team?: string; duration?: string; tools: string[] };
    userFlow: string[];
    wireframes: Screen[];
    uiDesign: { notes: string[]; palette?: Swatch[]; components?: string[] };
    finalScreens: Screen[];
  };
};

const FIGMA_FILE = "https://www.figma.com/design/wK4tHu1MQca0eBTLNQUsbP/Porto-Documentation";
const DEFAULT_TOOLS = ["Figma", "Figma AI", "Claude", "UX Pilot"];
/** Path helper for files in /public/images/projects/<slug>/<name>.webp */
const img = (slug: string, name: string) => `images/projects/${slug}/${name}.webp`;

/** Builds a case study skeleton for projects whose screens haven't been added yet. */
function placeholderProject(p: {
  slug: string;
  title: string;
  category: string;
  platform: string;
  tags: string[];
  mobile?: boolean;
}): Project {
  const d: Device = p.mobile ? "mobile" : "desktop";
  return {
    slug: p.slug,
    title: p.title,
    category: p.category,
    platform: p.platform,
    summary: `Add a one-line summary of ${p.title}: who uses it and what it helps them do.`,
    tags: p.tags,
    cover: { title: `${p.title} · main screen`, device: "desktop" },
    coverMobile: p.mobile ? { title: `${p.title} · mobile`, device: "mobile" } : undefined,
    caseStudy: {
      overview: `Describe ${p.title} in 2–3 sentences: the product, its users and the business context.`,
      problem: ["What made the old process slow, error-prone or confusing?", "Who was affected and how?"],
      solution: ["What did you design to solve it?", "Which design decision had the biggest impact?"],
      role: {
        title: "UI/UX Designer",
        responsibilities: ["User flow & information architecture", "Wireframes", "High-fidelity UI", "Prototype & developer handoff"],
        tools: DEFAULT_TOOLS,
      },
      userFlow: ["Entry point", "Main task", "Review / confirm", "Done"],
      wireframes: [
        { title: "Wireframe 1", device: d },
        { title: "Wireframe 2", device: d },
      ],
      uiDesign: { notes: ["Add notes on the visual language: colours, type, components."] },
      finalScreens: [
        { title: "Screen 1", device: "desktop" },
        { title: "Screen 2", device: "desktop" },
        ...(p.mobile ? [{ title: "Mobile screen", device: "mobile" as Device }] : []),
      ],
    },
  };
}

export const projects: Project[] = [

  /* ── CRM App: real screens from Figma (Porto Documentation › CRM - Web App) ── */
  {
    slug: "crm-app",
    title: "CRM App",
    category: "Enterprise Web App",
    industry: "Maritime services",
    platform: "Desktop web",
    summary:
      "A sales portal that takes every deal from Request for Quotation to quotation, approval and proforma invoice, with aging alerts so no request is left waiting.",
    tags: ["CRM", "Sales pipeline", "Dashboard", "Approval flow"],
    featured: true,
    figmaUrl: `${FIGMA_FILE}?node-id=161-6581`,
    prototypeUrl: "",
    cover: { title: "Dashboard", device: "desktop", src: "images/projects/crm-app/dashboard.webp" },
    caseStudy: {
      // Draft copy written from the Figma screens. Edit to match the real project.
      overview:
        "CRM Sales Portal is the daily workspace for a sales team handling maritime service requests. It brings RFQs, quotations, approvals, orders, proforma invoices and invoices into one connected flow, with a dashboard that shows what needs attention today.",
      problem: [
        "RFQs, quotations and approvals sit in one long sales cycle, and requests that wait too long cost deals.",
        "Quotations go through several revisions and approvals, so sales staff lose track of which version was sent and why it was rejected.",
        "Managers need a quick read of invoices, quotations and leads without opening every record.",
      ],
      solution: [
        "Aging badges (\"10+ days aging\") and a Pending RFQs panel on the dashboard surface requests that need action first.",
        "Clear status chips (New, Drafting, Waiting, Approved, Rejected, Cancelled) on every list, with filters by status, customer, sales person and date.",
        "One-step \"Convert to Quotation\" from the RFQ detail, confirmed in a focused dialog.",
        "Quotation detail with item breakdown, totals and a Version History tab, plus Resend and Create Revision actions.",
      ],
      role: {
        title: "UI/UX Designer",
        responsibilities: [
          "Mapped the RFQ → Quotation → Approval → PFI flow",
          "Designed dashboard, list, detail and dialog patterns",
          "Defined status system and table/filter components",
          "Prepared prototype and developer handoff",
        ],
        tools: DEFAULT_TOOLS,
      },
      userFlow: [
        "Dashboard",
        "RFQ list",
        "RFQ detail",
        "Convert to Quotation",
        "Quotation list",
        "Quotation detail & revision",
        "PFI detail",
      ],
      wireframes: [
        { title: "Dashboard wireframe", device: "desktop" },
        { title: "RFQ detail wireframe", device: "desktop" },
      ],
      uiDesign: {
        notes: [
          "Deep navy sidebar keeps the many CRM modules grouped and scannable, while content sits on white cards.",
          "Colour is reserved for meaning: status chips and aging alerts, never decoration.",
          "Consistent page header pattern: title, short description and primary export actions on the right.",
        ],
        palette: [
          { name: "Navy (sidebar)", hex: "#004579" },
          { name: "Surface", hex: "#FFFFFF" },
          { name: "Canvas", hex: "#F7F8FA" },
        ],
        components: ["Stat cards", "Filter bar", "Data table", "Status chips", "Aging badge", "Confirm dialog", "Tabs", "Breadcrumb"],
      },
      finalScreens: [
        { title: "Dashboard", device: "desktop", src: "images/projects/crm-app/dashboard.webp" },
        { title: "Request for Quotation", device: "desktop", src: "images/projects/crm-app/rfq.webp" },
        { title: "Detail RFQ", device: "desktop", src: "images/projects/crm-app/rfq-detail.webp" },
        { title: "Convert to New Quotation", device: "desktop", src: "images/projects/crm-app/rfq-convert.webp" },
        { title: "List Quotation", device: "desktop", src: "images/projects/crm-app/quotation.webp" },
        { title: "Detail Quotation", device: "desktop", src: "images/projects/crm-app/quotation-detail.webp" },
      ],
    },
  },


  /* ── ERP App: real screens from Figma (Porto Documentation › ERP - Web App) ── */
  {
    slug: "erp-app",
    title: "ERP App",
    category: "Enterprise Web App",
    industry: "Maritime services",
    platform: "Desktop web",
    summary:
      "A finance portal for journals, budgets and receivables, where every journal must balance before it posts and every customer record carries its fiscal settings.",
    tags: ["ERP", "Accounting", "Finance", "Data tables"],
    featured: true,
    figmaUrl: `${FIGMA_FILE}?node-id=162-9866`,
    prototypeUrl: "",
    cover: { title: "Dashboard Summary", device: "desktop", src: "images/projects/erp-app/dashboard.webp" },
    caseStudy: {
      overview:
        "ERP Finance Portal covers accounting, receivables, payables, reporting, assets and inventory for a maritime operations group. The designs shown focus on the dashboard, journal entries, budgets and the customer master data.",
      problem: [
        "Accountants enter many journal lines at once, and an unbalanced journal is easy to miss until month-end.",
        "Draft and posted records look alike in long tables, slowing down review.",
        "Customer data spans contacts, addresses, bank accounts, sales and tax settings, which is too much for one flat form.",
      ],
      solution: [
        "Journal line editor with live Total Debit / Total Credit and an inline \"Data does not match the balance\" warning; Create stays disabled until it balances.",
        "Tabs for All / Draft / Posted with counts, Group by, column picker and a summary row on every table.",
        "Customer detail split into tabs (View, Contact, Address, Bank Accounts, Sales) with grouped cards for sales, purchase, system and fiscal settings.",
        "\"Sync master data from HCMS\" so departments and branches stay consistent across systems.",
      ],
      role: {
        title: "UI/UX Designer",
        responsibilities: [
          "Information architecture for the finance modules",
          "Table, filter and form patterns for accounting data",
          "Validation and error states for journal entry",
          "High-fidelity UI and handoff",
        ],
        tools: DEFAULT_TOOLS,
      },
      userFlow: [
        "Dashboard summary",
        "Journal entries",
        "Create journal: lines",
        "Create journal: narration",
        "Post journal",
        "Budget list",
        "Customer list & detail",
      ],
      wireframes: [
        { title: "Journal entry wireframe", device: "desktop" },
        { title: "Customer detail wireframe", device: "desktop" },
      ],
      uiDesign: {
        notes: [
          "Shares the navy shell with the CRM and HCMS products so users move between systems without relearning navigation.",
          "Dense tables use quiet row dividers and small status pills (Adjusted, Synced, Draft, Posted).",
          "KPI cards use a coloured left edge to separate revenue, profit, assets and partners at a glance.",
        ],
        palette: [
          { name: "Navy (sidebar)", hex: "#004579" },
          { name: "Surface", hex: "#FFFFFF" },
          { name: "Canvas", hex: "#F7F8FA" },
        ],
        components: ["KPI cards", "Bar chart", "Segmented tabs", "Data table", "Line-item editor", "Inline validation", "Row action menu"],
      },
      finalScreens: [
        { title: "Dashboard Summary", device: "desktop", src: "images/projects/erp-app/dashboard.webp" },
        { title: "Journal Entries", device: "desktop", src: "images/projects/erp-app/journal.webp" },
        { title: "Create New Journal: Lines", device: "desktop", src: "images/projects/erp-app/journal-create.webp" },
        { title: "Budget List", device: "desktop", src: "images/projects/erp-app/budget.webp" },
        { title: "Customer List", device: "desktop", src: "images/projects/erp-app/customers.webp" },
        { title: "View Customer", device: "desktop", src: "images/projects/erp-app/customer-detail.webp" },
      ],
    },
  },

  /* ── HCMS App: real screens from Figma (Porto Documentation › HCMS - Web App) ── */
  {
    slug: "hcms-app",
    title: "HCMS App",
    category: "Enterprise Web & Mobile",
    industry: "Human capital",
    platform: "Desktop web · Responsive mobile",
    summary:
      "An employee self-service portal for attendance, expense requests, payslips, training and leave, designed for desktop with a matching mobile version of every screen.",
    tags: ["HCMS", "Self-service", "Responsive", "Forms"],
    featured: true,
    figmaUrl: `${FIGMA_FILE}?node-id=162-9917`,
    prototypeUrl: "",
    cover: { title: "Dashboard", device: "desktop", src: "images/projects/hcms-app/dashboard.webp" },
    coverMobile: { title: "Dashboard · mobile", device: "mobile", src: "images/projects/hcms-app/m-dashboard.webp" },
    caseStudy: {
      overview:
        "HCMS Employee Portal gives every employee one place to clock in and out, raise expense requests, download payslips, follow assigned training and apply for leave. Each desktop screen has a responsive mobile counterpart for staff away from a desk.",
      problem: [
        "Employees need to finish small HR tasks quickly, often from a phone.",
        "Expense requests involve many dependent fields (branch → department, category → sub-category) that are easy to fill in wrongly.",
        "Leave and training information is scattered, so employees keep asking HR for status updates.",
      ],
      solution: [
        "Dashboard opens with attendance: Clock In / Clock Out with the recorded times, plus awards, warnings and complaints counters.",
        "Request form grouped into Request information, Expense details and Line items, with dependent dropdowns and a running total.",
        "Payslip list filtered by month with one-tap view and download.",
        "Leave calendar with a colour legend per leave type, plus Pending / Rejected tabs.",
        "Mobile layouts stack the same sections, with primary actions pinned to the bottom.",
      ],
      role: {
        title: "UI/UX Designer",
        responsibilities: [
          "Self-service flows for attendance, requests, payroll, training and leave",
          "Responsive layouts for desktop and mobile",
          "Form patterns and validation states",
          "Prototype and developer handoff",
        ],
        tools: DEFAULT_TOOLS,
      },
      userFlow: ["Dashboard", "Clock in / out", "New request", "Submit or save draft", "Payslip", "Training details", "Leave application"],
      wireframes: [
        { title: "Request form wireframe", device: "desktop" },
        { title: "Mobile dashboard wireframe", device: "mobile" },
      ],
      uiDesign: {
        notes: [
          "Same navy shell as ERP and CRM so the three products read as one suite.",
          "Large, friendly attendance controls; secondary information in soft tinted cards.",
          "On mobile the sidebar becomes a top bar with a menu, and forms run full width.",
        ],
        palette: [
          { name: "Navy (sidebar)", hex: "#004579" },
          { name: "Surface", hex: "#FFFFFF" },
          { name: "Canvas", hex: "#F7F8FA" },
        ],
        components: ["Attendance card", "Counter cards", "Grouped form", "Month filter", "Leave calendar", "Status pills", "Sticky action bar"],
      },
      finalScreens: [
        { title: "Dashboard", device: "desktop", src: "images/projects/hcms-app/dashboard.webp" },
        { title: "New Request", device: "desktop", src: "images/projects/hcms-app/request.webp" },
        { title: "Pay Slip", device: "desktop", src: "images/projects/hcms-app/payslip.webp" },
        { title: "Training Details", device: "desktop", src: "images/projects/hcms-app/training.webp" },
        { title: "Leave Applications", device: "desktop", src: "images/projects/hcms-app/leave.webp" },
        { title: "Dashboard · mobile", device: "mobile", src: "images/projects/hcms-app/m-dashboard.webp" },
      ],
    },
  },

  /* ── MBG App: real screens from Figma (Porto Documentation › MBG - Mobile App) ── */
  {
    slug: "mbg-app",
    title: "MBG App",
    category: "Mobile App",
    industry: "Public sector · School nutrition",
    platform: "iOS · Android",
    summary:
      "An ordering app for Indonesia's free school-meal programme (Makan Bergizi Gratis): schools browse nutritious menus, order from several vendors at once and switch on automatic catering.",
    tags: ["Mobile", "E-commerce", "Multi-role login", "Public service"],
    featured: true,
    figmaUrl: `${FIGMA_FILE}?node-id=0-1`,
    prototypeUrl: "",
    cover: { title: "Beranda", device: "mobile", src: img("mbg-app", "home") },
    caseStudy: {
      // Draft copy written from the Figma screens. Edit to match the real project.
      overview:
        "MBG connects schools with food vendors, suppliers, producers and distributors for the free nutritious-meal programme. The app covers onboarding for every role, product discovery with nutrition information, a multi-vendor cart, checkout, transactions and automatic catering orders.",
      problem: [
        "Many different users (schools, vendors, suppliers, producers, distributors) must sign in, and some already have a KTADBRNR account while others don't.",
        "Meals have to meet nutrition needs, so buyers need nutrition facts before they order, not after.",
        "Schools order every day, which makes repeating the same order by hand tedious.",
      ],
      solution: [
        "Two clear entry points on the welcome screen: sign in with an MBG account or with KTADBRNR, with separate flows mapped for each role and account state.",
        "Product detail with a dedicated Nutrition Information view, plus reviews and store information.",
        "Cart grouped by store, with a dedicated flow for checking out from two different vendors.",
        "\"Pesan Katering Otomatis\" bottom sheet to switch on automatic catering orders matched to the students' age.",
        "Designed empty, offline, loading and failed-load states for every key screen.",
      ],
      role: {
        title: "UI/UX Designer",
        responsibilities: [
          "Role-based onboarding and login flows (MBG and KTADBRNR)",
          "Home, catalogue, product and nutrition screens",
          "Cart, checkout, transactions and auto-order",
          "Edge cases: empty, offline, loading and error states",
        ],
        tools: DEFAULT_TOOLS,
      },
      userFlow: ["Welcome", "Sign in (MBG / KTADBRNR)", "OTP", "Choose role & complete data", "Home", "Product & nutrition", "Cart", "Checkout", "Transaction"],
      wireframes: [
        { title: "Home wireframe", device: "mobile" },
        { title: "Checkout wireframe", device: "mobile" },
      ],
      uiDesign: {
        notes: [
          "Warm orange carries the MBG brand on onboarding; a trustworthy blue leads the shopping experience.",
          "Large food photography and rounded cards keep the catalogue friendly for school staff.",
          "Bottom sheets with illustrations for important confirmations such as auto-order and logout.",
        ],
        palette: [
          { name: "MBG orange", hex: "#EF6604" },
          { name: "Primary blue", hex: "#1555B8" },
          { name: "Surface", hex: "#FFFFFF" },
        ],
        components: ["Category grid", "Product card", "Promo banner", "Store-grouped cart", "Quantity stepper", "Bottom sheet", "Bottom navigation"],
      },
      finalScreens: [
        { title: "Onboarding: sign in", device: "mobile", src: img("mbg-app", "onboarding") },
        { title: "Beranda (Home)", device: "mobile", src: img("mbg-app", "home") },
        { title: "Produk", device: "mobile", src: img("mbg-app", "produk") },
        { title: "Keranjang (Cart)", device: "mobile", src: img("mbg-app", "keranjang") },
        { title: "Pesanan otomatis", device: "mobile", src: img("mbg-app", "otomatis") },
        { title: "Profile: keluar", device: "mobile", src: img("mbg-app", "profile") },
      ],
    },
  },

  /* ── UDIN Pay: real screens from Figma (Porto Documentation › UDIN - Mobile app) ── */
  {
    slug: "udin-pay",
    title: "UDIN Pay",
    category: "Mobile App",
    industry: "Fintech · E-wallet",
    platform: "iOS · Android · Landing page",
    summary:
      "An e-wallet with PIN and OTP onboarding, premium upgrade through e-KTP and selfie verification, six top-up channels, transfers, bill payments, points and promos, plus a merchant landing page.",
    tags: ["Fintech", "E-wallet", "KYC", "Payments"],
    featured: true,
    figmaUrl: `${FIGMA_FILE}?node-id=8-18164`,
    prototypeUrl: "",
    cover: { title: "Dashboard", device: "mobile", src: img("udin-pay", "dashboard") },
    caseStudy: {
      overview:
        "UDIN Pay is a consumer e-wallet. The designs cover registration and PIN setup, the wallet dashboard, premium upgrade with identity verification, top up from minimarkets, m-banking, internet banking, BCA OneKlik, ATM and card, transfers, cash withdrawal, bills (PLN, PDAM, BPJS, internet, phone), history, points and promos. A marketing landing page introduces UDIN for merchants.",
      problem: [
        "Every top-up channel works differently, and users get lost between bank apps, virtual accounts and minimarket codes.",
        "Identity verification (e-KTP + selfie) is required for premium features but easily abandoned halfway.",
        "Users need to trust a money app at first glance, including when the network fails.",
      ],
      solution: [
        "One Top Up hub, with a step-by-step screen per channel and virtual-account numbers that copy in one tap.",
        "A two-step premium upgrade (Scan KTP → Foto Selfie) with a progress indicator, framing guide and confirmation screen.",
        "Dashboard puts balance, points and the four core actions (Top Up, Transfer, Tarik Tunai, Riwayat) above the fold.",
        "Transaction history filtered by month with colour-coded amounts, plus an export option.",
        "Designed loading, lost-connection and failed-load states.",
      ],
      role: {
        title: "UI/UX Designer",
        responsibilities: [
          "Registration, OTP and PIN flows",
          "Wallet dashboard, top up, transfer and bills",
          "KYC upgrade flow (e-KTP + selfie)",
          "UDIN Merchant landing page",
        ],
        tools: DEFAULT_TOOLS,
      },
      userFlow: ["On-boarding", "Register & OTP", "Set PIN", "Dashboard", "Top up channel", "Pay / transfer", "Enter PIN", "Transaction detail"],
      wireframes: [
        { title: "Dashboard wireframe", device: "mobile" },
        { title: "Top up wireframe", device: "mobile" },
      ],
      uiDesign: {
        notes: [
          "Energetic red-to-orange gradient header for brand recognition; white content cards for clarity.",
          "Money always in the largest type on screen; credits in green, debits in red.",
          "Friendly illustrations on onboarding balance the seriousness of a finance app.",
        ],
        palette: [
          { name: "UDIN red", hex: "#F03325" },
          { name: "Action orange", hex: "#F15A24" },
          { name: "Surface", hex: "#FFFFFF" },
        ],
        components: ["Balance card", "Quick actions", "Service grid", "Channel list", "Copy field", "Stepper", "Transaction row", "Bottom navigation"],
      },
      finalScreens: [
        { title: "On-boarding", device: "mobile", src: img("udin-pay", "onboarding") },
        { title: "Dashboard", device: "mobile", src: img("udin-pay", "dashboard") },
        { title: "Top up: m-banking", device: "mobile", src: img("udin-pay", "topup") },
        { title: "Upgrade premium: scan e-KTP", device: "mobile", src: img("udin-pay", "scan-ktp") },
        { title: "Riwayat transaksi", device: "mobile", src: img("udin-pay", "riwayat") },
        { title: "UDIN Merchant landing page", device: "desktop", src: img("udin-pay", "landing"), tall: true },
      ],
    },
  },

  /* ── UDIN Payment Gateway Admin: real screens from Figma (Porto Documentation › UDIN - Web admin) ── */
  {
    slug: "udin-admin",
    title: "UDIN Payment Gateway Admin",
    category: "Web Admin",
    industry: "Fintech · Payment gateway",
    platform: "Desktop web",
    summary:
      "The back office behind UDIN's payment gateway: balances and transactions, company onboarding through five verification states, access keys for integrations and role-based admin access.",
    tags: ["Admin panel", "Fintech", "Verification", "Roles"],
    figmaUrl: `${FIGMA_FILE}?node-id=9-31822`,
    prototypeUrl: "",
    cover: { title: "Dashboard Admin", device: "desktop", src: img("udin-admin", "dashboard") },
    caseStudy: {
      overview:
        "A web admin for the team running UDIN's payment gateway. Admins monitor balances, profit per product line (PPOB, LIVE, BLANJA, Travel) and transactions, review companies that apply to integrate, issue access keys and manage merchants, projects and admin roles.",
      problem: [
        "Company applications move through several states (not yet approved, activating, under review, active, failed verification), each needing different admin actions.",
        "Access keys are sensitive and must be easy to issue but hard to expose by accident.",
        "Different admins (finance, operations, regulator) should only see the pages relevant to them.",
      ],
      solution: [
        "Colour-coded status pills on the company list, with a dedicated detail layout and actions for each state.",
        "Access-key flow with input, saved confirmation and a masked \"view key\" step.",
        "Role management: create roles, assign pages and sub-menus, and see each role's page count at a glance.",
        "Dashboard with daily totals, a monthly transaction chart and partner payment-method split.",
      ],
      role: {
        title: "UI/UX Designer",
        responsibilities: [
          "Admin information architecture",
          "Company verification flows and states",
          "Access-key and role-management flows",
          "UI built on the UDIN design system",
        ],
        tools: DEFAULT_TOOLS,
      },
      userFlow: ["Login", "Dashboard", "Data perusahaan", "Review detail", "Approve / reject", "Add access key", "Manage roles"],
      wireframes: [
        { title: "Company review wireframe", device: "desktop" },
        { title: "Role management wireframe", device: "desktop" },
      ],
      uiDesign: {
        notes: [
          "Dark sidebar separates the admin tool from the consumer brand, with UDIN red reserved for active states and primary actions.",
          "Plain, high-contrast tables optimised for scanning many records.",
          "Built entirely from the UDIN Design System components.",
        ],
        palette: [
          { name: "Sidebar", hex: "#181818" },
          { name: "UDIN red", hex: "#E83A33" },
          { name: "Surface", hex: "#FFFFFF" },
        ],
        components: ["Dark sidebar", "Stat cards", "Bar & donut chart", "Data table", "Status pills", "Tabs", "Modal confirmations"],
      },
      finalScreens: [
        { title: "Login", device: "desktop", src: img("udin-admin", "login") },
        { title: "Dashboard Admin", device: "desktop", src: img("udin-admin", "dashboard") },
        { title: "Transaksi", device: "desktop", src: img("udin-admin", "transaksi") },
        { title: "Data Perusahaan", device: "desktop", src: img("udin-admin", "data") },
        { title: "Manajemen Role", device: "desktop", src: img("udin-admin", "role") },
      ],
    },
  },

  /* ── Pangan Segar: real screens from Figma (Porto Documentation › Pangan segar - Web admin) ── */
  {
    slug: "pangan-segar",
    title: "Pangan Segar Admin",
    category: "Web Admin",
    industry: "Retail · Fresh groceries",
    platform: "Desktop web",
    summary:
      "An admin dashboard for a fresh-grocery store: orders from packed to delivered, product catalogue and categories, recipes, delivery slots and drivers, promo games and user roles.",
    tags: ["Admin panel", "E-commerce", "Operations", "Bilingual"],
    figmaUrl: `${FIGMA_FILE}?node-id=2-20458`,
    prototypeUrl: "",
    cover: { title: "Beranda", device: "desktop", src: img("pangan-segar", "beranda") },
    caseStudy: {
      overview:
        "Pangan Segar's admin panel is where the store team runs daily operations: confirming orders, managing products and categories, publishing recipes, tracking income, setting delivery schedules and drivers, running promos and games, and managing admin accounts and roles. The interface switches between Indonesian and English.",
      problem: [
        "Fresh food has a short shelf life, so orders must move quickly from confirmation to delivery.",
        "Delivery is sold in time slots with different fees, which the team changes often.",
        "Products come in many categories and sub-categories (beef cuts, vegetables, fish) with stock to watch.",
      ],
      solution: [
        "Dashboard with today's orders, daily income and new users, best-selling products and a recent-orders summary.",
        "Order confirmation flow with clear states (packed, shipped, done) and a full order-detail dialog.",
        "Delivery schedule editor: priority and standard options, hourly slots, fee per slot and on/off toggles.",
        "Product list with category tabs, stock, status (active / archived) plus import and add actions.",
      ],
      role: {
        title: "UI/UX Designer",
        responsibilities: [
          "Admin IA and navigation",
          "Order, product, recipe and delivery flows",
          "Promo games and role management",
          "Success, failure and empty states",
        ],
        tools: DEFAULT_TOOLS,
      },
      userFlow: ["Login", "Beranda", "Pesanan masuk", "Konfirmasi pesanan", "Dikemas", "Dikirim", "Selesai"],
      wireframes: [
        { title: "Dashboard wireframe", device: "desktop" },
        { title: "Delivery schedule wireframe", device: "desktop" },
      ],
      uiDesign: {
        notes: [
          "Fresh green brand colour signals freshness and marks active navigation and primary actions.",
          "Orange is kept for save actions and attention states so it never competes with the brand green.",
          "Soft tinted table headers and generous row spacing for long product and order lists.",
        ],
        palette: [
          { name: "Fresh green", hex: "#4ACF39" },
          { name: "Surface", hex: "#FFFFFF" },
          { name: "Canvas", hex: "#F3F4F8" },
        ],
        components: ["Stat cards", "Income chart", "Best-seller list", "Data table", "Category tabs", "Order dialog", "Time-slot editor", "Toggle"],
      },
      finalScreens: [
        { title: "Login Admin", device: "desktop", src: img("pangan-segar", "login") },
        { title: "Beranda", device: "desktop", src: img("pangan-segar", "beranda") },
        { title: "Detail Pesanan", device: "desktop", src: img("pangan-segar", "pesanan") },
        { title: "Daftar Produk", device: "desktop", src: img("pangan-segar", "produk") },
        { title: "Jadwal Pengiriman", device: "desktop", src: img("pangan-segar", "jadwal") },
      ],
    },
  },

  /* ── MyCloudIndo: real screens from Figma (Porto Documentation › Mycloudindo - Web) ── */
  {
    slug: "mycloudindo",
    title: "MyCloudIndo Website",
    category: "Website",
    industry: "Cloud infrastructure",
    platform: "Responsive website",
    summary:
      "A marketing website for an Indonesian cloud provider: landing page, a detail page per service (Dedicated VPS, Cloud VPS, Object Storage, DRC, Kubernetes, Private VPN), promos, partnership, documentation and contact.",
    tags: ["Website", "Landing page", "B2B", "Responsive"],
    figmaUrl: `${FIGMA_FILE}?node-id=1-18419`,
    prototypeUrl: "",
    cover: { title: "Landing Page", device: "desktop", src: img("mycloudindo", "landing"), tall: true },
    caseStudy: {
      overview:
        "MyCloudIndo sells local and hybrid cloud services to businesses. The website explains each service, shows nationwide coverage and compatible technologies, builds trust with client logos and an SLA promise, and leads visitors to contact sales or claim a promo. Every page also has a mobile layout.",
      problem: [
        "Six technical services need to be understood by both IT teams and business decision-makers.",
        "A local provider has to prove it is reliable against global cloud brands.",
        "Promos and package specs change often and must be easy to compare.",
      ],
      solution: [
        "Service tabs on the landing page and a consistent detail-page template for every service.",
        "Trust sections: coverage map across Indonesia, compatible stacks, 99.98% SLA promise and logos of known clients.",
        "Package comparison cards with clear specs and one CTA each; promo page with copyable promo codes.",
      ],
      role: {
        title: "UI/UX Designer",
        responsibilities: ["Site map and page templates", "Landing page and 6 service pages", "Promo, partnership, documentation and contact pages", "Mobile responsive layouts"],
        tools: DEFAULT_TOOLS,
      },
      userFlow: ["Landing page", "Service tabs", "Service detail", "Compare packages", "Promo", "Contact sales"],
      wireframes: [
        { title: "Landing wireframe", device: "desktop" },
        { title: "Mobile wireframe", device: "mobile" },
      ],
      uiDesign: {
        notes: [
          "Confident cloud blue with isometric 3D illustrations communicates modern infrastructure.",
          "A rounded, friendly display face keeps a technical subject approachable.",
          "Repeating section system (hero → proof → services → CTA) so every page feels part of one site.",
        ],
        palette: [
          { name: "Cloud blue", hex: "#4271E5" },
          { name: "Surface", hex: "#FFFFFF" },
          { name: "Mist", hex: "#F3F6FC" },
        ],
        components: ["Hero with illustration", "Promo ticker", "Coverage map", "Service tabs", "Feature list", "Package cards", "Logo wall", "Footer"],
      },
      finalScreens: [
        { title: "Landing Page", device: "desktop", src: img("mycloudindo", "landing"), tall: true },
        { title: "Detail Layanan: Dedicated VPS", device: "desktop", src: img("mycloudindo", "vps"), tall: true },
        { title: "Promo", device: "desktop", src: img("mycloudindo", "promo"), tall: true },
      ],
    },
  },

  /* ── ESP Design: real screens from Figma (Porto Documentation › Drilling - Web Engineer) ── */
  {
    slug: "esp-design",
    title: "ESP Design for Drilling Engineers",
    category: "Enterprise Web App",
    industry: "Oil & gas",
    platform: "Desktop web",
    summary:
      "An engineering tool for designing electric submersible pumping systems: wellbore inputs draw a live well schematic, and directional-survey data plots as MD vs TVD, MD vs angle and a 3D top view.",
    tags: ["Oil & gas", "Engineering", "Data visualisation", "Forms"],
    figmaUrl: `${FIGMA_FILE}?node-id=17-27513`,
    prototypeUrl: "",
    cover: { title: "Wellbore Data: well schematics", device: "desktop", src: img("esp-design", "casing") },
    caseStudy: {
      overview:
        "ESP Design Overview helps drilling and production engineers design and analyse an electric submersible pump. A guided workflow (well description, wellbore data, fluid properties, inflow, design criteria, equipment selection) turns raw well data into schematics and plots the engineer can check while typing.",
      problem: [
        "Engineers enter dozens of technical values with different units (feet, inches, °F) and mistakes are hard to spot in a plain form.",
        "Casing, tubing and pump depth only make sense when you can see the well, not just the numbers.",
        "Directional-survey tables are long and need to be pasted in from other tools.",
      ],
      solution: [
        "Side-by-side layout: inputs on the left, a live well schematic on the right labelled with the entered values.",
        "Unit selector on every field group, and a calculated mid-perforation datum shown read-only.",
        "Flowing Temperature Gradient graph in a dialog with Simple Linear, Linear (with pump & motor) and Ramey models.",
        "Directional-survey table with copy/paste, plus Depth vs Distance (MD vs TVD, MD vs Angle) and 3D top-view trajectory plots.",
        "Designed empty states that tell the engineer what to enter next.",
      ],
      role: {
        title: "UI/UX Designer",
        responsibilities: ["Workflow structure for the ESP design process", "Engineering forms with units and validation", "Well schematic and chart presentation", "Empty and warning states"],
        tools: DEFAULT_TOOLS,
      },
      userFlow: ["Well description", "Wellbore data", "Casing & tubing", "View FTG graph", "Directional survey", "Trajectory plots", "Next: fluid properties"],
      wireframes: [
        { title: "Wellbore data wireframe", device: "desktop" },
        { title: "Directional survey wireframe", device: "desktop" },
      ],
      uiDesign: {
        notes: [
          "Calm, neutral interface so the technical schematic and charts carry the colour.",
          "A single cyan accent marks the current workflow step and primary actions.",
          "Charts use clear axis labels and units that match the input fields.",
        ],
        palette: [
          { name: "Engineering cyan", hex: "#25ABE2" },
          { name: "Surface", hex: "#FFFFFF" },
          { name: "Canvas", hex: "#F7F9FB" },
        ],
        components: ["Workflow stepper", "Unit selector", "Field groups", "Well schematic", "Line chart", "3D plot", "Data grid with paste", "Empty state"],
      },
      finalScreens: [
        { title: "Wellbore Data: empty case", device: "desktop", src: img("esp-design", "empty") },
        { title: "Add Casing & Tubing: well schematics", device: "desktop", src: img("esp-design", "casing") },
        { title: "View FTG graph", device: "desktop", src: img("esp-design", "ftg") },
        { title: "Directional Survey: MD vs TVD", device: "desktop", src: img("esp-design", "tvd") },
        { title: "Directional Survey: 3D top view", device: "desktop", src: img("esp-design", "topview") },
      ],
    },
  },

  /* ── UDIN Design System: real screens from Figma (Porto Documentation › Design System) ── */
  {
    slug: "design-system",
    title: "UDIN Design System",
    category: "Design System",
    industry: "Fintech",
    platform: "Figma library",
    summary:
      "The component library behind the UDIN products: buttons in every size and state, text fields with validation, icons, headers, tables, sidebars, pop-ups and a full colour scale with contrast ratings.",
    tags: ["Design system", "Components", "Tokens", "Accessibility"],
    figmaUrl: `${FIGMA_FILE}?node-id=17-33959`,
    prototypeUrl: "",
    cover: { title: "Colors", device: "desktop", src: img("design-system", "colors"), tall: true },
    caseStudy: {
      overview:
        "The UDIN Design System keeps the UDIN Pay app, the payment-gateway admin and the merchant dashboard consistent. Every component is documented with a short definition, its sizes and its states, so designers and developers build from the same source.",
      problem: [
        "Several UDIN products were being designed in parallel, and the same button or field started to look different in each.",
        "Developers needed every state (hover, loading, success, disabled, error) defined, not just the default.",
        "Brand colours had to stay readable across light and dark surfaces.",
      ],
      solution: [
        "Buttons in S, M and L with default, hover, loading, success, disabled and link variants, plus ghost and Google buttons.",
        "Text fields covering default, password, icon, error and locked states with helper messages.",
        "Outline and bold icon sets, header and table-title patterns, sidebar and pop-up templates.",
        "Yellow, red and orange scales from light to darker, each swatch with hex, RGB and contrast rating, plus gradient, icon and state colours.",
      ],
      role: {
        title: "UI/UX Designer",
        responsibilities: ["Component audit across UDIN products", "Component variants and states", "Colour scale with contrast checks", "Documentation for developers"],
        tools: DEFAULT_TOOLS,
      },
      userFlow: ["Audit existing screens", "Define tokens", "Build components", "Document states", "Apply to products", "Hand off to developers"],
      wireframes: [],
      uiDesign: {
        notes: [
          "Each documentation page opens with a plain-language definition of the component.",
          "Variants are laid out as a size × state matrix so gaps are obvious.",
          "Contrast ratings sit on every colour swatch to guide accessible text colour choices.",
        ],
        palette: [
          { name: "Red · normal", hex: "#F03524" },
          { name: "Orange · normal", hex: "#F57C21" },
          { name: "Yellow · normal", hex: "#F8931F" },
        ],
        components: ["Button", "Ghost button", "Text field", "Radio card", "Upload", "Dropdown", "Card", "Tab", "Breadcrumb", "Icon", "Header", "Table", "Sidebar", "Pop-up"],
      },
      finalScreens: [
        { title: "Components: Button", device: "desktop", src: img("design-system", "button"), tall: true },
        { title: "Components: Text field & inputs", device: "desktop", src: img("design-system", "textfield"), tall: true },
        { title: "Icon, header & table", device: "desktop", src: img("design-system", "icon"), tall: true },
        { title: "Sidebar & pop-up", device: "desktop", src: img("design-system", "sidebar"), tall: true },
        { title: "Colors", device: "desktop", src: img("design-system", "colors"), tall: true },
      ],
    },
  },

  /* ── Design Exploration: real screens from Figma (Porto Documentation › Design Exploration) ── */
  {
    slug: "design-exploration",
    title: "Design Exploration: Education Platform",
    category: "Mobile App",
    industry: "Education",
    platform: "Mobile concept",
    summary:
      "Self-initiated concepts for a professional learning platform (dashboard, course player, discovery, course detail, leaderboard) and a redesign of the Aku Pintar home screen.",
    tags: ["Concept", "EdTech", "Gamification", "Redesign"],
    figmaUrl: `${FIGMA_FILE}?node-id=72-7395`,
    prototypeUrl: "",
    cover: { title: "Leaderboard", device: "mobile", src: img("design-exploration", "leaderboard") },
    caseStudy: {
      overview:
        "A personal exploration of how a learning app for working professionals could feel: progress you can see, short modules, certifications and a little friendly competition. It also includes a redesign of the Aku Pintar home screen for students choosing a university.",
      problem: [
        "Busy professionals start online courses and rarely finish them.",
        "Learning progress and certificates are usually hidden deep in a profile.",
        "Aku Pintar's home screen had many features competing for attention.",
      ],
      solution: [
        "Dashboard opens with the course in progress, time left and one Continue button.",
        "Course player combines the video, curriculum with locked/unlocked lessons and certification progress.",
        "Leaderboard with weekly, monthly and all-time ranking and a nudge to climb the ranks.",
        "Aku Pintar redesign groups features into clear shortcuts and one hero recommendation.",
      ],
      role: {
        title: "UI/UX Designer (self-initiated)",
        responsibilities: ["Concept and user journeys", "Visual exploration", "High-fidelity mobile screens"],
        tools: DEFAULT_TOOLS,
      },
      userFlow: ["Onboarding & login", "Dashboard", "Discover course", "Course details & enrol", "Course player", "Quiz", "Certificate", "Leaderboard"],
      wireframes: [],
      uiDesign: {
        notes: [
          "One deep blue as the learning colour, with green for completion and gold for rank.",
          "Real photography for courses to make the catalogue feel premium.",
          "Progress bars and percentages on every course card to encourage completion.",
        ],
        palette: [
          { name: "Learning blue", hex: "#2155D5" },
          { name: "Surface", hex: "#FFFFFF" },
          { name: "Canvas", hex: "#F5F7FB" },
        ],
        components: ["Progress card", "Course card", "Curriculum list", "Video player", "Rank podium", "Tabs", "Bottom navigation"],
      },
      finalScreens: [
        { title: "Training dashboard", device: "mobile", src: img("design-exploration", "dashboard") },
        { title: "Course player", device: "mobile", src: img("design-exploration", "player") },
        { title: "Discover", device: "mobile", src: img("design-exploration", "discover"), tall: true },
        { title: "Course details", device: "mobile", src: img("design-exploration", "course"), tall: true },
        { title: "Leaderboard", device: "mobile", src: img("design-exploration", "leaderboard") },
        { title: "Aku Pintar: redesign beranda", device: "mobile", src: img("design-exploration", "akupintar") },
      ],
    },
  },

  /* ── Placeholders: add screens & Figma links for these projects ── */
  placeholderProject({
    slug: "auth-system",
    title: "Auth System",
    category: "Enterprise Web App",
    platform: "Web",
    tags: ["Authentication", "Access control"],
  }),
  placeholderProject({
    slug: "mydewaruci",
    title: "MyDewaruci",
    category: "Web & Mobile App",
    platform: "Web · Mobile",
    tags: ["Mobile", "Web"],
    mobile: true,
  }),
  placeholderProject({
    slug: "register-app",
    title: "Register App",
    category: "Enterprise Web App",
    platform: "Web",
    tags: ["Registration", "Workflow"],
  }),
  placeholderProject({
    slug: "ops-app",
    title: "OPS App",
    category: "Enterprise Web App",
    platform: "Web",
    tags: ["Operations", "Dashboard"],
  }),
  placeholderProject({
    slug: "rules-development-system",
    title: "Rules Development System",
    category: "Enterprise Web App",
    platform: "Web",
    tags: ["Document workflow", "Review & approval"],
  }),
  placeholderProject({
    slug: "certificate-app",
    title: "Certificate App",
    category: "Web & Mobile App",
    platform: "Web · Mobile",
    tags: ["Certificates", "Verification"],
    mobile: true,
  }),
];

export const getProject = (slug: string) => projects.find((p) => p.slug === slug);
/** Up to three mobile screens for the phone-trio cover, with the project cover in the middle. */
export const coverPhones = (p: Project): Screen[] => {
  const others = p.caseStudy.finalScreens.filter((s) => s.device === "mobile" && s.src && s.src !== p.cover.src);
  return [others[0], p.cover, others[1]].filter(Boolean) as Screen[];
};
export const hasRealScreens = (p: Project) => Boolean(p.cover.src);
export const categories = ["All", ...Array.from(new Set(projects.map((p) => p.category)))];
