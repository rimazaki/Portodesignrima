/**
 * ─────────────────────────────────────────────────────────────
 *  PROFILE: edit this file to update your personal details.
 *  Everything on the site (hero, about, contact, footer) reads from here.
 * ─────────────────────────────────────────────────────────────
 */

export const profile = {
  name: "Rima Zakiyatin",
  firstName: "Rima",
  initials: "RZ",
  role: "UI/UX Designer",
  experienceYears: "5+",
  location: "Indonesia · Open to remote",

  headline: "I design enterprise software that makes complex operations feel simple.",
  intro:
    "UI/UX Designer with 5+ years of experience shaping web and mobile products for ERP, CRM, HCMS and the maritime, shipping and oil & gas industries, from the first user flow to developer-ready screens.",

  /** Longer bio for the About page. One string per paragraph. */
  bio: [
    "I'm a UI/UX Designer who enjoys the hard problems: data-heavy dashboards, multi-step approval flows and systems used every day by sales, finance, HR and engineering teams.",
    "Over the last 5+ years I have designed web and mobile products across ERP, CRM, HCMS, maritime and shipping management, and oil & gas engineering tools. My work covers research, information architecture, wireframes, high-fidelity UI, interactive prototypes and design systems that keep large products consistent.",
    "I work closely with product owners and engineers, so every screen ships with clear states, edge cases and a clean developer handoff.",
  ],

  /** Optional photo. Put a file in /public/images/ and set e.g. "images/rima.jpg". Leave empty to show initials. */
  photo: "",

  email: "rimazakiyatin@gmail.com",
  /** TODO: replace with your real LinkedIn URL. */
  linkedin: "https://www.linkedin.com/in/your-linkedin-handle",
  /** Put your CV at /public/cv/Rima-Zakiyatin-CV.pdf (same file name) and the Download CV buttons will serve it. */
  cvUrl: "cv/Rima-Zakiyatin-CV.pdf",
  /** Optional main Figma portfolio link. */
  figma: "https://www.figma.com/design/wK4tHu1MQca0eBTLNQUsbP/Porto-Documentation",

  specializations: [
    "Web & Mobile Design",
    "Enterprise Applications",
    "ERP",
    "CRM",
    "HCMS",
    "Maritime Management System",
    "Shipping Management",
    "Oil & Gas Management System",
  ],

  tools: [
    { name: "Figma", note: "UI, prototyping, design systems" },
    { name: "Figma AI", note: "Faster exploration & content" },
    { name: "Claude", note: "Research synthesis & UX writing" },
    { name: "UX Pilot", note: "AI-assisted wireframes & flows" },
  ],

  /**
   * Work experience shown as a timeline on the About page.
   * TODO: replace the placeholder entries with your real roles.
   */
  experience: [
    {
      period: "20XX – Present",
      role: "UI/UX Designer",
      company: "Company name",
      summary: "Replace with 1–2 lines about your scope, e.g. enterprise ERP, CRM and HCMS products for the maritime industry.",
    },
    {
      period: "20XX – 20XX",
      role: "UI/UX Designer",
      company: "Company name",
      summary: "Replace with 1–2 lines about your scope and the products you designed.",
    },
  ],
} as const;

export type Skill = { name: string; description: string; icon: SkillIcon };
export type SkillIcon =
  | "palette" | "compass" | "search" | "wireframe" | "play" | "layers" | "devices" | "code";

export const skills: Skill[] = [
  { name: "UI Design", icon: "palette", description: "Clean, accessible interfaces with clear hierarchy for dense, data-heavy screens." },
  { name: "UX Design", icon: "compass", description: "Information architecture and flows that shorten the path to a finished task." },
  { name: "User Research", icon: "search", description: "Stakeholder interviews, task analysis and usability reviews with real operators." },
  { name: "Wireframing", icon: "wireframe", description: "Low- to mid-fidelity layouts to align teams before pixels get expensive." },
  { name: "Prototyping", icon: "play", description: "Interactive Figma prototypes for testing flows and demoing to clients." },
  { name: "Design System", icon: "layers", description: "Reusable components, tokens and states that keep large products consistent." },
  { name: "Responsive Design", icon: "devices", description: "Layouts that hold up from wide desktop dashboards down to mobile." },
  { name: "Developer Handoff", icon: "code", description: "Annotated specs, edge cases and empty, error and loading states, ready to build." },
];

export const process = [
  { step: "01", title: "Understand", text: "Business goals, users and the existing workflow." },
  { step: "02", title: "Define", text: "User flows, information architecture and scope." },
  { step: "03", title: "Design", text: "Wireframes, then high-fidelity UI on a shared design system." },
  { step: "04", title: "Validate", text: "Prototype, review with stakeholders and iterate." },
  { step: "05", title: "Deliver", text: "Developer handoff with every state documented." },
];
